package dataobjects;

/**
 * Created by CostelRo on 08.08.2018.
 */


public enum ProductCategory
{
    BOOKS,
    COMPUTERS,
    CLOTHES,
    FURNITURE,
    MOBILES,
    TOYS,
    TV;
}
