package dataobjects;

/**
 * Created by CostelRo on 08.08.2018.
 */


public class Address
{
    // fields
    private String country;
    private String locality;
    private String street;
    private String number;


    // constructors
    public Address( String country, String locality, String street, String number )
    {
        this.country = country;
        this.locality = locality;
        this.street = street;
        this.number = number;
    }

    public Address( Address addressToDuplicate )
    {
        this( addressToDuplicate.getCountry(),
              addressToDuplicate.getLocality(),
              addressToDuplicate.getStreet(),
              addressToDuplicate.getNumber() );
    }


    // getters and setters
    public String getCountry()
    {
        return this.country;
    }

    public void setCountry(String newCountry)
    {
        if( newCountry != null && newCountry.length() > 0 )
        {
            this.country = newCountry.trim();
        }
    }

    public String getLocality()
    {
        return this.locality;
    }

    public void setLocality(String newLocality)
    {
        if( newLocality != null && newLocality.length() > 0 )
        {
            this.locality = newLocality.trim();
        }
    }

    public String getStreet()
    {
        return this.street;
    }

    public void setStreet(String newStreet)
    {
        if( newStreet != null && newStreet.length() > 0 )
        {
            this.street = newStreet.trim();
        }
    }

    public String getNumber()
    {
        return this.number;
    }

    public void setNumber(String newNumber)
    {
        if( newNumber != null && newNumber.length() > 0 )
        {
            this.number = newNumber.trim();
        }
    }


    //other methods
    @Override
    public String toString()
    {
        return this.getLocality() + ", " + this.getCountry().toUpperCase()
               + ", street " + this.getStreet() + " no. " + this.getNumber();
    }


    @Override
    public boolean equals( Object other )
    {
        if( this == other )
        {
            return true;
        }
        if( other == null || this.getClass() != other.getClass() )
        {
            return false;
        }

        Address otherAddress = (Address) other;
        if ( !country.equals( otherAddress.country )
             || !locality.equals( otherAddress.locality )
             || !street.equals( otherAddress.street)
             || !number.equals( otherAddress.number ) )
        {
            return false;
        }

        return true;
    }


    @Override
    public int hashCode()
    {
        int result = country.hashCode();

        result = 31 * result + locality.hashCode();
        result = 31 * result + street.hashCode();
        result = 31 * result + number.hashCode();

        return result;
    }
}
