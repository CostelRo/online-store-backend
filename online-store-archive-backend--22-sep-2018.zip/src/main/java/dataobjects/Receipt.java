package dataobjects;


import databaseworker.DBConnectionPool;
import databaseworker.ReceiptSqlQueries;

import java.sql.Connection;
import java.util.List;
import java.util.Map;


/**
 * This class creates Receipts, according to the project requirements specifications.
 * A Receipt is uniquely associated with a Cart from the database.
 */
public class Receipt
{
    // fields
    private static          int counter = 1;
    private         final   Integer idJava;
    private         final   Cart cartFromDB;
    private         final   List<Payment> paymentsFromDB;


    // constructors
    public Receipt( Cart cartInDB, List<Payment> paymentsInDB )
    {
        this.idJava = counter;
        counter++;
        this.cartFromDB = cartInDB;
        this.paymentsFromDB = paymentsInDB;
    }


    // getters
    public Integer getIdJava() { return this.idJava; }

    public Cart getCartFromDB() { return this.cartFromDB; }

    public List<Payment> getPaymentsFromDB() { return this.paymentsFromDB; }


    // other methods
    /**
     * This method writes a Receipt object to a database.
     * @param receipt the Receipt object
     * @return int the ID of the Receipt in the database if the operation was successful, or -1 otherwise
     */
    public int writeReceiptToDatabase( Receipt receipt, int idCartDB )
    {
        int result = -1;

        if( receipt != null )
        {
            Connection con = DBConnectionPool.getMysqlConnection();

            if( con != null )
            {
                result = ReceiptSqlQueries.insertReceiptIntoMysql( receipt, idCartDB, con );
                DBConnectionPool.closeConnection( con );
            }
            else
            {
                System.out.println( "Error: connection unavailable, try again!" );
            }
        }

        return result;
    }


    /**
     * This method reads data from the database and creates a Receipt object.
     * @param idReceiptDB the ID of the Receipt in the database
     * @param con a database connection
     */
    public Receipt readReceiptFromDatabase( int idReceiptDB, Connection con )
    {
        Receipt result = null;

        con = DBConnectionPool.getMysqlConnection();
        if( con != null )
        {
            result = ReceiptSqlQueries.getReceiptByIDFromMysql( idReceiptDB, con );
            DBConnectionPool.closeConnection( con );
        }
        else
        {
            System.out.println( "Error: connection unavailable, try again!" );
        }

        return result;
    }


    public double computeTotalAmount()
    {
        double result = 0;

        Map<ProductCategory, Double> purchases = this.getCartFromDB().getPurchases();
        for( ProductCategory category : purchases.keySet() )
        {
            result += purchases.get( category );
        }

        return result;
    }


    @Override
    public String toString()
    {
        Map<ProductCategory, Double> purchases = this.getCartFromDB().getPurchases();
        StringBuilder sbPurchases = new StringBuilder(  );
        for( ProductCategory category : purchases.keySet() )
        {
            sbPurchases.append( category.name().toLowerCase() )
                    .append( ": " ).append( purchases.get( category ) )
                    .append( "; " );
        }

        List<Payment> payments = this.getPaymentsFromDB();
        StringBuilder sbPayments = new StringBuilder();
        for( Payment pay : payments )
        {
            sbPayments.append( pay.getType().name().toLowerCase() )
                    .append( ": " ).append( pay.getAmount() )
                    .append( "; " );
        }

        return "Receipt for cart " + this.cartFromDB.getIdJava() + " (" + this.cartFromDB.getDate() + ")\n"
                + sbPurchases.toString()
                + "TOTAL = " + this.cartFromDB.computeTotalAmount()
                + "\nPaid with:\n" + sbPayments.toString();
    }
}
