package actions.filters;


import databaseworker.CustomerSqlQueries;
import databaseworker.DBConnectionPool;
import dataobjects.Address;
import dataobjects.Customer;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;


/**
 * This class provides methods for filtering the Customers in the database using various criteria.
 */
public class CustomerFilters
{
    /**
     * This method creates Customer objects from data in the database.
     * @param idCustomersDB a set of database IDs of customers
     * @return a map of pairs (database-Customer-ID, Customer-object)
     */
    public static Map<Integer, Customer> searchByManyIDs( Set<Integer> idCustomersDB )
    {
        Map<Integer, Customer> result = new TreeMap<>();

        try( Connection con = DBConnectionPool.getMysqlConnection() )
        {
            // getting the data from the database
            Map<Integer, List<String>> queryResults = CustomerSqlQueries.getCustomersDataByIDFromMysql( idCustomersDB,
                                                                                                        con );

            // creating the objects from the database data
            for( int key : queryResults.keySet() )
            {
                List<String> data = queryResults.get( key );

                Integer idCustomerDB = Integer.valueOf( data.get(0) ) ;
                if( !result.containsKey( idCustomerDB ) )
                {
                    // add all new data for the existing Customer already in 'result'
                    Address newAddress = new Address( data.get(4),
                                                      data.get(5),
                                                      data.get(6),
                                                      data.get(7) );
                    Customer newCustomer = new Customer( data.get(1),
                                                         data.get(2),
                                                         data.get(3),
                                                         newAddress );
                    newCustomer.addToBuyingHistoryByCartID( Integer.parseInt( data.get(8) ) );

                    result.put( idCustomerDB, newCustomer );
                }
                else
                {
                    // add the new Customer data to 'result'
                    Customer customer = result.get( idCustomerDB );

                    Address newAddress = new Address( data.get(4),
                                                      data.get(5),
                                                      data.get(6),
                                                      data.get(7) );
                    customer.addAddress( newAddress );
                    customer.addToBuyingHistoryByCartID( Integer.parseInt( data.get(8) ) );
                }
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return result;
    }


    /**
     * This method creates at most one Customer object from data in the database.
     * @param idCustomerDB int = the database ID of a customers
     * @return a map of pairs (database-Customer-ID, Customer-object)
     */
    public static Map<Integer, Customer> searchByOneID( int idCustomerDB )
    {
        Set<Integer> idCustomers = new HashSet<>();
        idCustomers.add( idCustomerDB );

        return CustomerFilters.searchByManyIDs( idCustomers );
    }
}
