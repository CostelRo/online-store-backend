package actions.pdfworker;


import dataobjects.Cart;
import dataobjects.Payment;
import dataobjects.ProductCategory;
import dataobjects.Receipt;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;


/**
 * This class creates new PDF documents from data in Receipt objects.
 * The current implementation uses the Apache PDFBox API (https://pdfbox.apache.org/).
 */
public class ReceiptPDFWriter
{
    public static String write( Receipt receipt, int idReceiptDB )
    {
        String result = null;

        // an official recommended setting for higher rendering speed on Java 8 and 9
        System.setProperty( "sun.java2d.cmm", "sun.java2d.cmm.kcms.KcmsServiceProvider" );

        try( PDDocument doc = new PDDocument() )
        {
            // prepare text for insertion into the PDF file
            Cart cart = receipt.getCartFromDB();
            String title = "RECEIPT no " + idReceiptDB + " (from: " + cart.getDate() + ")";
            String separator1 = "========================================";
            String totalValueString = "TOTAL AMOUNT = " + receipt.computeTotalAmount() + " RON";
            String paymentsIntro = "Receipt paid with:";

            // insert all text into a new page of the PDF file
            doc.addPage( new PDPage() );
            PDPage page = doc.getPage( 0 );
            try( PDPageContentStream contentStream = new PDPageContentStream( doc, page ) )
            {
                contentStream.beginText();

                contentStream.setFont( PDType1Font.TIMES_BOLD, 20 );
                contentStream.setLeading( 14.5f );
                contentStream.newLineAtOffset( 40, 700 );
                contentStream.showText( title );
                contentStream.newLine();

                contentStream.setFont( PDType1Font.TIMES_ROMAN, 14 );

                contentStream.showText( separator1 );
                contentStream.newLine();

                contentStream.showText( totalValueString );
                contentStream.newLine();

                Map<ProductCategory, Double> purchases = cart.getPurchases();
                for( ProductCategory category : purchases.keySet() )
                {
                    String textLine = "- " + category.name().toLowerCase() + ": "
                                      + purchases.get( category ) + " RON";
                    contentStream.showText( textLine );
                    contentStream.newLine();
                }

                contentStream.newLine();
                contentStream.showText( paymentsIntro );
                contentStream.newLine();

                List<Payment> payments = receipt.getPaymentsFromDB();
                for( Payment payment : payments )
                {
                    String textLine = "- " + payment.getType().name().toLowerCase()
                                      + ": "  + payment.getAmount() + " RON";
                    contentStream.showText( textLine );
                    contentStream.newLine();
                }

                contentStream.showText( separator1 );
                contentStream.newLine();

                contentStream.endText();
            }
            catch( IOException ioe )
            {
                ioe.printStackTrace();
            }

            // saving the new PDF file
            String filepath = "Receipt #" + idReceiptDB + ".pdf";
            result = filepath;
            doc.save( new File( filepath ) );
        }
        catch( IOException ioe )
        {
            ioe.printStackTrace();
        }

        return result;
    }
}
