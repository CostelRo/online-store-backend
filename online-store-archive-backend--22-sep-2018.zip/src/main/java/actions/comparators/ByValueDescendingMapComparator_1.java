package actions.comparators;

import java.util.Comparator;
import java.util.Map;


public class ByValueDescendingMapComparator_1 implements Comparator<Map.Entry<String, Double>>
{
    public int compare( Map.Entry<String, Double> e1, Map.Entry<String, Double> e2 )
    {
        return e2.getValue().compareTo( e1.getValue() );
    }
}
