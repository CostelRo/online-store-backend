package actions.reporter;


import actions.webworker.ReportAsWebPage;
import databaseworker.ReportSqlQueries;

import java.time.LocalDate;
import java.time.Month;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;


/**
 * This class creates various reports with data from the database.
 * The reports will be accessible at the addresses indicated in the 'webworker.ReportAsWebPage' class;
 * the current implementation makes them accessible at addresses with the general format: "http://localhost:4567/..."
 */
public class Report
{
    /**
     * This method crates a report with the total sales for one day.
     * @param day the day for which the report collects and displays available data
     */
    public static void dailySales( LocalDate day )
    {
        String title = "Total Sales for " + day ;
        Map<String, Object> source = new HashMap<>();
        source.put( "title", title );

        Map<String, Object> data = new HashMap<>();
        String name = "TOTAL";

        double amount;
        if( day == LocalDate.now() )
        {
            amount = ReportSqlQueries.getTotalSalesForToday();
        }
        else
        {
            amount = ReportSqlQueries.getTotalSalesForOneDay( day );
        }

        data.put( "name", name );
        data.put( "amount", amount );
        source.put( "data", data );

        ReportAsWebPage.dailyTotalSales( source );
    }


    /**
     * This method crates a report with the total sales per each category for one month.
     * @param month the month for which the report collects and displays available data
     * @param year the year to which the month parameter refers
     */
    public static void monthlyCategoriesSales( int month, int year )
    {
        String title = "Total Sales per Category for " + Month.of( month ) + " " + year;
        Map<String, Object> source = new HashMap<>();
        source.put( "title", title );

        Set<Map.Entry<String, Double>> data;
        if( year == LocalDate.now().getYear()
            && month == LocalDate.now().getMonthValue() )
        {
            data = ReportSqlQueries.getTotalSalesPerCategoryForCurrentMonth().entrySet();
        }
        else if( year == LocalDate.now().getYear()
                 && month == (LocalDate.now().getMonthValue() - 1) )
        {
            data = ReportSqlQueries.getTotalSalesPerCategoryForPreviousMonth().entrySet();
        }
        else
        {
            data = ReportSqlQueries.getTotalSalesPerCategoryForOneMonth( month, year ).entrySet();
        }
        source.put( "data", data );

        ReportAsWebPage.monthlySalesPerCategory( source );
    }


    /**
     * This method crates a report with a top of the best sold categories for one month.
     * @param month the month for which the report collects and displays available data
     * @param year the year to which the month parameter refers
     * @param topSize the number of records in the top
     */
    public static void monthlyTopCategoriesBySales(int month, int year, int topSize )
    {
        String title = "TOP " + topSize + " Sales per Category for " + Month.of( month ) + " " + year;
        Map<String, Object> source = new HashMap<>();
        source.put( "title", title );

        List<String> dbData = ReportSqlQueries.getTopCategoriesBySalesForOneMonth( topSize, month, year );
        Map<String, String> temp = new LinkedHashMap<>();
        for( String s : dbData )
        {
            String[] tokens = s.split(":");
            temp.put( tokens[0], tokens[1] );
        }
        Set<Map.Entry<String, String>> data = temp.entrySet();
        source.put( "data", data );

        ReportAsWebPage.topMonthlySalesPerCategory( source );
    }


    /**
     * This method crates a report with a top of the best sold categories for all-time.
     * @param topSize the number of records in the top
     */
    public static void alltimeTopCategoriesBySales(int topSize )
    {
        String title = "TOP " + topSize + " ALL-TIME Sales per Category";
        Map<String, Object> source = new HashMap<>();
        source.put( "title", title );

        List<String> dbData = ReportSqlQueries.getTopCategoriesBySalesAlltime( topSize );
        Map<String, String> temp = new LinkedHashMap<>();
        for( String s : dbData )
        {
            String[] tokens = s.split(":");
            temp.put( tokens[0], tokens[1] );
        }
        Set<Map.Entry<String, String>> data = temp.entrySet();
        source.put( "data", data );

        ReportAsWebPage.topAlltimeSalesPerCategory( source );
    }




    /**
     * This method crates a report with a top of the best customers by sales for one month.
     * @param month the month for which the report collects and displays available data
     * @param year the year to which the month parameter refers
     * @param topSize the number of records in the top
     */
    public static void monthlyTopCustomersBySales( int month, int year, int topSize )
    {
        String title = "TOP " + topSize + " Customers by Sales for " + Month.of( month ) + " " + year;
        Map<String, Object> source = new HashMap<>();
        source.put( "title", title );

        List<String> dbData = ReportSqlQueries.getTopCustomersBySalesForOneMonth( topSize, month, year );
        Map<String, String> temp = new LinkedHashMap<>();
        for( String s : dbData )
        {
            String[] tokens = s.split(":");
            String fullName = tokens[0];
            String email = tokens[1];
            String identity = fullName + " (" + email + ")";
            String amount = tokens[2];

            temp.put( identity, amount );
        }
        Set<Map.Entry<String, String>> data = temp.entrySet();
        source.put( "data", data );

        ReportAsWebPage.topMonthlyCustomersBySales( source );
    }
}
