package actions.webworker;


import com.github.mustachejava.DefaultMustacheFactory;
import com.github.mustachejava.Mustache;
import com.github.mustachejava.MustacheFactory;

import java.io.IOException;
import java.io.StringWriter;
import java.util.Map;

import static spark.Spark.get;


/**
 * This class provides methods for the creation of web pages using SparkJava based on Mustache templates.
 */
public class ReportAsWebPage
{
    public static void dailyTotalSales( Map<String, Object> source )
    {
        String reportFormat_dailySales = "public/report-daily-sales.mustache";
        get( "/daily-sales",
                  (rq, rs) -> renderWithMustache( source, reportFormat_dailySales ) );
    }


    public static void monthlySalesPerCategory( Map<String, Object> source )
    {
        String reportFormat_MonthlySales = "public/report-monthly-categories-sales.mustache";
        get( "/monthly-categories-sales",
                  (rq, rs) -> renderWithMustache( source, reportFormat_MonthlySales ) );
    }


    public static void topMonthlySalesPerCategory( Map<String, Object> source )
    {
        String reportFormat_MonthlySales = "public/report-top-categories-sales.mustache";
        get( "/top-monthly-categories-sales",
                  (rq, rs) -> renderWithMustache( source, reportFormat_MonthlySales ) );
    }


    public static void topAlltimeSalesPerCategory( Map<String, Object> source )
    {
        String reportFormat_MonthlySales = "public/report-top-categories-sales.mustache";
        get( "/top-alltime-categories-sales",
                  (rq, rs) -> renderWithMustache( source, reportFormat_MonthlySales ) );
    }


    public static void topMonthlyCustomersBySales( Map<String, Object> source )
    {
        String reportFormat_MonthlySales = "public/report-top-categories-sales.mustache";
        get( "/top-monthly-customers-sales",
                (rq, rs) -> renderWithMustache( source, reportFormat_MonthlySales ) );
    }


    private static String renderWithMustache( Map<String, Object> source, String reportFormat ) throws IOException
    {
        MustacheFactory mf = new DefaultMustacheFactory();
        Mustache m = mf.compile( reportFormat );

        StringWriter writer = new StringWriter();
        m.execute( writer, source ).close();

        return writer.toString();
    }
}
