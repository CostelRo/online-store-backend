package actions.csvworker;


import actions.strategy.CartStrategy;
import actions.strategy.CustomerStrategy;
import actions.strategy.PaymentStrategy;
import dataobjects.Cart;
import dataobjects.Customer;
import dataobjects.Payment;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by CostelRo on 20.08.2018.
 */

public class CSVArchiveImporter
{
    /**
     * This method imports the store's archived data from CSV files and inserts it into the store's new database.
     * @return a boolean indicating whether there was erroneous data in the CSVs or not
     */
    public static boolean importArchive( String customersCSVFile, String cartsCSVFile, String paymentsCSVFile )
    {
        // mapping from idCustomerCSV to corresponding idCustomerDB, used when inserting Carts and Payments to database
        Map<Integer, Integer> mappingCustomerIDs = new HashMap<>();

        // mapping from idCartCSV to corresponding idCartDB, used when inserting Payments to database
        Map<Integer, Integer> mappingCartIDs = new HashMap<>();

        // import all the store's archive from the CSV files
        importCustomersArchive( customersCSVFile, mappingCustomerIDs );
        importCartsArchive( cartsCSVFile, mappingCustomerIDs, mappingCartIDs );
        importPaymentsArchive( paymentsCSVFile, mappingCustomerIDs, mappingCartIDs );

        // TODO: Collect the erroneous rows from the CSV files in log files & announce their existence.
        return true;
    }


    private static void importCustomersArchive( String customersCSVFile,
                                                Map<Integer, Integer> mappingCustomerIDs )
    {
        Map<Integer, Object> parsedCustomers = CSVParser.getObjects( customersCSVFile, new CustomerStrategy() );

        for( Integer idCustomerCSV : parsedCustomers.keySet() )
        {
            Customer customer = (Customer) parsedCustomers.get( idCustomerCSV );

            int idCustomerDB = Customer.writeToDatabase( customer );

            mappingCustomerIDs.put( idCustomerCSV, idCustomerDB );
        }

        System.out.println( "Customers archive imported from CSV." );
    }


    private static void importCartsArchive( String cartsCSVFile,
                                            Map<Integer, Integer> mappingCustomerIDs,
                                            Map<Integer, Integer> mappingCartIDs )
    {
        Map<Integer, Object> parsedCarts = CSVParser.getObjects( cartsCSVFile, new CartStrategy() );

        for ( Integer idCartCSV : parsedCarts.keySet() )
        {
            Cart cartCSV = (Cart) parsedCarts.get( idCartCSV );
            int idCustomerCSV = cartCSV.getCustomerIDJava(); // it's an idCustomerCSV, see the CartStrategy
            int idCustomerDB = mappingCustomerIDs.get( idCustomerCSV );
            Cart properCart = new Cart( idCustomerDB, cartCSV.getDate(), cartCSV.getPurchases() );

            int idCartDB = Cart.writeToDatabase( properCart );

            mappingCartIDs.put( idCartCSV, idCartDB );
        }

        System.out.println( "Carts archive imported from CSV." );
    }


    private static void importPaymentsArchive( String paymentsCSVFile,
                                               Map<Integer, Integer> mappingCustomerIDs,
                                               Map<Integer, Integer> mappingCartIDs )
    {
        Map<Integer, Object> parsedPayments = CSVParser.getObjects( paymentsCSVFile, new PaymentStrategy() );

        for ( Integer idPaymentCSV : parsedPayments.keySet() )
        {
            Payment paymentCSV = (Payment) parsedPayments.get( idPaymentCSV );

            int idCartCSV = paymentCSV.getCartIDJava(); // now it's an idCartCSV (all data came from CSV)
            int idCartDB = mappingCartIDs.get( idCartCSV );
            int idCustomerCSV = paymentCSV.getCustomerIDJava(); // now it's an idCustomerCSV (all data came from CSV)
            int idCustomerDB = mappingCustomerIDs.get( idCustomerCSV );
            Payment properPayment = new Payment( idCartDB, idCustomerDB,
                                                 paymentCSV.getStatus(), paymentCSV.getType(), paymentCSV.getAmount() );

            int idPaymentDB = Payment.writeToDatabase(properPayment);
        }

        System.out.println( "Payments archive imported from CSV." );
    }
}
