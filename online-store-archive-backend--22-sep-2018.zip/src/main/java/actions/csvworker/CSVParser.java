package actions.csvworker;


import actions.strategy.DataObjectStrategy;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Created by CostelRo on 14.08.2018.
 */


public class CSVParser
{
    /**
     * The method parses a CSV file and creates objects of the type indicated by the 'strategy' argument.
     * @param file the CSV file used as data source
     * @param strategy indicates the type of objects kept in the CSV file
     * @return a Map<Integer, Object> with:
     *           - keys = the old index in the CSV archives of the objects created by this method
     *           - values = the objects created by this method
     */
    public static Map<Integer, Object> getObjects( String file, DataObjectStrategy strategy )
    {
        Map<Integer, Object> result = new TreeMap<>();

        List<String> fileContents = CSVParser.getFileContents( file, strategy );
        for( String line : fileContents )
        {
            List<Object> parsedResult = strategy.parseObjectFromCSVString( line );
            result.put( (Integer)parsedResult.get(0), parsedResult.get(1) );
        }

        return result;
    }


    private static List<String> getFileContents( String file, DataObjectStrategy strategy )
    {
        List<String> result = new ArrayList<>();

        if( file != null )
        {
            String fileHeaderStart = DataObjectStrategy.CSV_HEADER_START;
            String currentLine;

            try( BufferedReader br = new BufferedReader( new FileReader( file ) ) )
            {
                while( (currentLine = br.readLine()) != null )
                {
                    // Some programs, including Microsoft Notepad,
                    // add a byte order mark '\uFEFF' at the beginning of UTF-encoded files
                    // (which should have been stripped automatically, but Java doesn't do that).
                    if ( currentLine.startsWith("\uFEFF") )
                    {
                        currentLine = String.copyValueOf( currentLine.toCharArray(),
                                                    1,
                                                    currentLine.length()-1 );
                    }
                    if( strategy.isValidLine( currentLine ) && !currentLine.startsWith( fileHeaderStart ) )
                        {
                            result.add( currentLine );
                        }
                }
            }
            catch( IOException ex )
            {
                ex.printStackTrace();
            }
        }

        return result;
    }
}
