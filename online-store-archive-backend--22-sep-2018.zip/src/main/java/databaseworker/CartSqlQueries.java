package databaseworker;

import actions.strategy.CartStrategy;
import dataobjects.Cart;
import dataobjects.ProductCategory;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;


/**
 * Created by CostelRo on 17.08.2018.
 */


public final class CartSqlQueries
{
    /**
     * This method inserts a Cart object into a database.
     * @param properCart a Cart object which contains the database ID of the Customer it is related to
     * @param con a Connection to the database
     * @return the ID of the Cart in the database if the operation was successful, or -1 otherwise
     * NOTE: A finalized Cart and its related finalized Payments are logically connected
     * (although the Payments are not part of the Cart).
     * Because of this, adding a Cart should automatically continue with the addition of its connected Payments.
     */
    public static int insertCartIntoMysql( Cart properCart, Connection con )
    {
        int idCartDB = -1;

        final String command = "INSERT INTO cart (idCustomer, date) VALUES (?, ?)";
        try( PreparedStatement pstmt = con.prepareStatement( command ) )
        {
            int idCustomerDB = properCart.getCustomerIDJava();  // this idCustomer is a proper idCustomerDB
            pstmt.setInt( 1, idCustomerDB );
            pstmt.setDate( 2, Date.valueOf( properCart.getDate() ) );

            pstmt.executeUpdate();

            // Insert the purchases information from this Cart object
            idCartDB = CartSqlQueries.getLatestUsedID( con );

            if( idCartDB > 0 )
            {
                for( ProductCategory category : properCart.getPurchases().keySet() )
                {
                    String product = category.name().toLowerCase();
                    double amount = properCart.getPurchases().get( category );

                    CartSqlQueries.insertPurchaseIntoMysql( idCartDB, idCustomerDB, product, amount, con );
                }
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return idCartDB;
    }


    /**
     * This method inserts the purchases information from inside a Cart object into the database.
     * @param category the product category name of a purchase from the Cart object
     * @param amount the purchase value for the current product category
     * @param idCartDB the Cart to which this purchase object belongs
     * @param idCustomerDB the Customer to which this purchase object belongs
     * @param con a Connection to the database
     */
    private static void insertPurchaseIntoMysql( int idCartDB, int idCustomerDB, String category, double amount,
                                                 Connection con )
    {
        final String command = "INSERT INTO purchase (idCart, idCustomer, category, amount) VALUES (?, ?, ?, ?)";
        try( PreparedStatement pstmt = con.prepareStatement( command ) )
        {
            pstmt.setInt( 1, idCartDB );
            pstmt.setInt( 2, idCustomerDB );
            pstmt.setString( 3, category );
            pstmt.setDouble( 4, amount );

            pstmt.executeUpdate();
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }
    }


    /**
     * This method returns the ID in the database of the last inserted Cart.
     * @param con a Connection to the database
     * @return the ID of the Cart from the database if the operation is successful, or -1 otherwise
     */
    private static int getLatestUsedID( Connection con )
    {
        int idCartDB = -1;

        final String command = "SELECT MAX(idCart) FROM cart";
        try( PreparedStatement pstmt = con.prepareStatement( command );
             ResultSet rs = pstmt.executeQuery() )
        {
            while( rs.next() )
            {
                idCartDB = rs.getInt( 1 );
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return idCartDB;
    }


    /**
     * This method creates a Cart object from data in the database.
     * @param idCart the ID of the desired Cart in the database
     * @param con a Connection to the database
     * @return the Cart object created if the operation is successful, or -1 otherwise
     */
    public static Cart getCartFromMysql( int idCart, Connection con )
    {
        Cart result = null;

        final String command = "SELECT cart.idCustomer, cart.date, purchase.category, purchase.amount "
                               + "FROM cart JOIN purchase ON cart.idCart = purchase.idCart "
                               + "WHERE cart.idCart = ?";
        try( PreparedStatement pstmt = con.prepareStatement( command ) )
        {
            pstmt.setInt( 1, idCart );

            try( ResultSet rs = pstmt.executeQuery() )
            {
                // a Cart may contain more than one pair of values (category, amount)
                int idCustomer = -1;
                LocalDate date = null;
                Map<ProductCategory, Double> purchases = new HashMap<>();
                while( rs.next() )
                {
                    idCustomer               = rs.getInt( "cart.idCustomer" );
                    date                     = rs.getDate( "cart.date" ).toLocalDate();
                    ProductCategory category = CartStrategy.getProductCategory(
                                                                       rs.getString( "purchase.category" ) );
                    Double amount            = rs.getDouble( "purchase.amount" );
                    purchases.put( category, amount );
                }

                if (idCustomer > 0 && date != null)
                {
                    result = new Cart( idCustomer, date, purchases );
                }
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return result;
    }
}
