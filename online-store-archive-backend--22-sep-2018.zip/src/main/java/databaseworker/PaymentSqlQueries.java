package databaseworker;

import actions.strategy.PaymentStrategy;
import dataobjects.Payment;
import dataobjects.PaymentStatus;
import dataobjects.PaymentType;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public final class PaymentSqlQueries
{
    /**
     * This method inserts a Payment object into the database.
     * A finalized Cart and its related finalized Payments are always logically connected
     * (although the Payments are not part of the Cart).
     * Because of this, adding a new Cart should automatically continue with the addition of its connected Payments.
     * @param properPayment a Payment object, created at runtime, associated with a Cart already in the database,
     *                      and containing the correct database IDs for its associated Cart and Customer
     * @param con a Connection to the database
     * @return the ID of the Payment in the database if the operation was successful, or -1 otherwise
     */
    public static int insertPaymentIntoMysql( Payment properPayment, Connection con )
    {
        int idPayment = -1;

        // Get the database ID of the Customer and the Cart connected to this Payment
        int idCartDB = properPayment.getCartIDJava();           // it's an idCartDB (e.g. see CSVArchiveImporter)
        int idCustomerDB = properPayment.getCustomerIDJava();   // it's an idCustomerDB (e.g. see CSVArchiveImporter)

        // Insert the Payment object in the database
        String status = properPayment.getStatus().name().toLowerCase();
        String type = properPayment.getType().name().toLowerCase();
        double amount = properPayment.getAmount();
        final String command = "INSERT INTO payment (idCart, idCustomer, status, type, amount) " +
                               "VALUES (?, ?, ?, ?, ?)";
        try( PreparedStatement pstmt = con.prepareStatement( command ) )
        {
            pstmt.setInt( 1, idCartDB );
            pstmt.setInt( 2, idCustomerDB );
            pstmt.setString( 3, status );
            pstmt.setString( 4, type );
            pstmt.setDouble( 5, amount );

            pstmt.executeUpdate();
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return idPayment;
    }


    /**
     * This method discovers the database ID of a Cart.
     * @param idCartDB the database ID of a Cart
     * @param con a connection to the database
     * @return the database CustomerID associated with the Cart if successful, -1 otherwise
     */
    public static int getCustomerID( int idCartDB, Connection con )
    {
        int result = -1;

        final String command = "SELECT idCustomer FROM cart WHERE idCart = ?";
        try ( PreparedStatement pstmt = con.prepareStatement( command ) )
        {
            pstmt.setInt( 1, idCartDB );

            try( ResultSet rs = pstmt.executeQuery() )
            {
                while( rs.next() )
                {
                    result = rs.getInt( 1 );
                }
            }
        } catch ( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return result;
    }


    /**
     * This method creates a Payment object from data in the database.
     * @param idPaymentDB the ID of the desired Payment in the database
     * @param con a Connection to the database
     * @return the Payment object created if the operation is successful, or -1 otherwise
     */
    public static Payment getPaymentByIDFromMysql( int idPaymentDB, Connection con )
    {
        Payment result = null;

        final String command = "SELECT idCart, idCustomer, status, type, amount FROM payment WHERE idPayment = ?";
        try( PreparedStatement pstmt = con.prepareStatement( command ) )
        {
            pstmt.setInt( 1, idPaymentDB );

            try( ResultSet rs = pstmt.executeQuery() )
            {
                while( rs.next() )
                {
                    int idCartDB = rs.getInt( "idCart" );
                    int idCustomerDB = rs.getInt( "idCustomer" );
                    PaymentStatus status = PaymentStrategy.getPaymentStatus( rs.getString( "status" ) );
                    PaymentType type = PaymentStrategy.getPaymentType( rs.getString( "type" ) );
                    double amount = rs.getDouble( "amount" );

                    result = new Payment( idCartDB, idCustomerDB, status, type, amount );
                }
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return result;
    }


    /**
     * This method gets all Payment associated to a Cart in the database.
     * @param idCartDB the database ID of the Cart to which the desired Payment is associated
     * @param con a Connection to the database
     * @return a List of Payment objects
     */
    public static List<Payment> getPaymentsByCartFromMysql( int idCartDB, Connection con )
    {
        List<Payment> result = new ArrayList<>();

        final String command = "SELECT idCustomer, status, type, amount FROM payment WHERE idCart = ?";
        try( PreparedStatement pstmt = con.prepareStatement( command ) )
        {
            pstmt.setInt( 1, idCartDB );

            try( ResultSet rs = pstmt.executeQuery() )
            {
                while( rs.next() )
                {
                    int idCustomerDB = rs.getInt( "idCustomer" );
                    PaymentStatus status = PaymentStrategy.getPaymentStatus( rs.getString( "status" ) );
                    PaymentType type = PaymentStrategy.getPaymentType( rs.getString( "type" ) );
                    double amount = rs.getDouble( "amount" );

                    Payment newPayment = new Payment( idCartDB, idCustomerDB, status, type, amount );
                    result.add( newPayment );
                }
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return result;
    }
}
