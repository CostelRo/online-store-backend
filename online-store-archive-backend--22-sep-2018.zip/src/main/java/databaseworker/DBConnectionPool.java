package databaseworker;

/**
 * Created by CostelRo on 18.08.2018.
 */


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * This class creates and administers a database connection pool.
 * This implementation uses a MySQL database.
 */
public final class DBConnectionPool
{
    // fields
    private static          DBConnectionPool    instance;
    private static final    int                 LIMIT_MYSQL = 5;   // max. number of MySQL connections kept in the pool
    private static          List<Connection>    poolAvailableMysql;
    private static          List<Connection>    poolUsedMysql;


    // constructors
    private DBConnectionPool()
    {
        DBConnectionPool.poolAvailableMysql = new ArrayList<>( DBConnectionPool.LIMIT_MYSQL );
        DBConnectionPool.poolUsedMysql = new ArrayList<>( DBConnectionPool.LIMIT_MYSQL );
    }

    public static Connection getMysqlConnection()
    {
        // simplest version
        final String MYSQL_DRIVER = "com.mysql.cj.jdbc.Driver";
        final String MYSQL_HOST = "localhost";
        final String MYSQL_PORT = "3306";
        final String MYSQL_DATABASE = "wantsome-online-store-backend";
        final String parameters = "?allowPublicKeyRetrieval=true&useSSL=false";
        final String URL = "jdbc:mysql://" + MYSQL_HOST + ":" + MYSQL_PORT + "/" + MYSQL_DATABASE + parameters;
        final String user = "java";
        final String password = "great2018";

        Connection con = null;

        if( DBConnectionPool.instance == null )
        {
            DBConnectionPool.instance = new DBConnectionPool();
            try
            {
                Class.forName( MYSQL_DRIVER );
            }
            catch( ClassNotFoundException cnfe )
            {
                System.out.printf( "[dbpool1] Error: unable to load database driver class: %s\n", MYSQL_DRIVER);
                cnfe.printStackTrace();
            }
        }

        try
        {
            con = DriverManager.getConnection( URL, user, password );
        }
        catch( SQLException sqle )
        {
            System.out.println( "[dbpool2] Error: unable to create database connection!" );
            sqle.printStackTrace();
        }

        return con;


        // intention: a connections pool behavior
//        Connection result = null;
//
//        if( DBConnectionPool.instance == null )
//        {
//            DBConnectionPool.instance = new DBConnectionPool();
//            result = DBConnectionPool.getMysqlDBConnection();
//            DBConnectionPool.poolAvailableMysql.add( result );
//        }
//        else
//        {
//            if( DBConnectionPool.poolUsedMysql.size() < 5 )
//            {
//                if( DBConnectionPool.poolAvailableMysql.size() > 0 )
//                {
//                    result = DBConnectionPool.poolAvailableMysql.get( 0 );
//                }
//                else
//                {
//                    result = DBConnectionPool.getMysqlDBConnection();
//                    DBConnectionPool.poolAvailableMysql.add( result );
//                }
//            }
//        }
//
//        if( result != null )
//        {
//            DBConnectionPool.poolAvailableMysql.remove( result );
//            DBConnectionPool.poolUsedMysql.add( result );
//        }
//
//        return result;
    }


    // getters
    public int getLimitMysql()
    {
        return DBConnectionPool.LIMIT_MYSQL;
    }


    // other methods
    /**
     * This private method creates a connection to a MySQL database.
     * This method should be used only by the Connection Pool.
     * @return a working MySQL connection, or a null Connection in case of errors
     */
//    private static Connection getMysqlDBConnection()
//    {
//        final String MYSQL_DRIVER = "com.mysql.cj.jdbc.Driver";
//        final String MYSQL_HOST = "localhost";
//        final String MYSQL_PORT = "3306";
//        final String MYSQL_DATABASE = "wantsome-online-store-backend";
//        final String URL = "jdbc:mysql://" + MYSQL_HOST + ":" + MYSQL_PORT + "/" + MYSQL_DATABASE + "?useSSL=false";
//        final String user = "java";
//        final String password = "great2018";
//
//        Connection result = null;
//
//        try
//        {
//            Class.forName( MYSQL_DRIVER );
//        }
//        catch( ClassNotFoundException cnfe )
//        {
//            System.out.println( "Error: unable to load database driver class!" );
//            cnfe.printStackTrace();
//        }
//
//        try
//        {
//            result = DriverManager.getConnection(URL, user, password);
//        }
//        catch( SQLException sqle )
//        {
//            System.out.println( "Error: unable to create database connection!" );
//            sqle.printStackTrace();
//        }
//
//        return result;
//    }


    public static void closeConnection( Connection con )
    {
        // simplest version
        if( con != null )
        {
            try
            {
                con.close();
            }
            catch ( SQLException sqle )
            {
                sqle.printStackTrace();
            }
        }


        // intention: a connections pool behavior
//        DBConnectionPool.poolUsedMysql.remove( con );
//        DBConnectionPool.poolAvailableMysql.add( con );
    }


    public static int getAvailableMysqlConnectionsCount()
    {
        return DBConnectionPool.poolAvailableMysql.size();
    }


    public static int getUsedMysqlConnectionsCount()
    {
        return DBConnectionPool.poolUsedMysql.size();
    }
}
