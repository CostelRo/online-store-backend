package databaseworker;


import actions.reporter.ReportTools;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class ReportSqlQueries
{
    public static double getTotalSalesForToday()
    {
        return ReportSqlQueries.getTotalSalesForOneDay( LocalDate.now() );
    }


    public static double getTotalSalesForOneDay( LocalDate date )
    {
        double result = 0;

        // === Get a database connection ===
        Connection con = DBConnectionPool.getMysqlConnection();

        // === Collect data from the database ===
        final String command = "SELECT amount "
                               + "FROM purchase JOIN cart ON purchase.idCart = cart.idCart "
                               + "WHERE cart.date = ?";
        try( PreparedStatement pstmt = con.prepareStatement( command ) )
        {
            pstmt.setDate( 1, Date.valueOf( date ) );

            try( ResultSet rs = pstmt.executeQuery() )
            {
                while( rs.next() )
                {
                    result += rs.getDouble( 1 );
                }
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        // === Close the database connection ===
        DBConnectionPool.closeConnection( con );

        return result;
    }


    public static Map<String, Double> getTotalSalesPerCategoryForCurrentMonth()
    {
        LocalDate today = LocalDate.now();

        return ReportSqlQueries.getTotalSalesPerCategoryForOneMonth( today.getMonthValue(),
                                                                     today.getYear() );
    }


    public static Map<String, Double> getTotalSalesPerCategoryForPreviousMonth()
    {
        LocalDate previousMonth = LocalDate.now().minusMonths( 1 );

        return ReportSqlQueries.getTotalSalesPerCategoryForOneMonth( previousMonth.getMonthValue(),
                                                                     previousMonth.getYear() );
    }


    public static Map<String, Double> getTotalSalesPerCategoryForOneMonth( int month, int year )
    {
        Map<String, Double> result = new HashMap<>();

        // === Get a database connection ===
        Connection con = DBConnectionPool.getMysqlConnection();

        // === Collect data from the database ===
        final String command = "SELECT purchase.category, purchase.amount "
                                + "FROM purchase JOIN cart ON purchase.idCart = cart.idCart "
                                + "WHERE YEAR(cart.date) = ? AND MONTH(cart.date) = ?";
        try( PreparedStatement pstmt = con.prepareStatement( command ) )
        {
            pstmt.setInt( 1, year );
            pstmt.setInt( 2, month );

            try( ResultSet rs = pstmt.executeQuery() )
            {
                while( rs.next() )
                {
                    String category = rs.getString( 1 );
                    Double amount = rs.getDouble( 2 );

                    result.put( category, amount + result.getOrDefault( category, 0.0 ) );
                }
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        // === Close the database connection ===
        DBConnectionPool.closeConnection( con );

        return result;
    }


    public static List<String> getTopCategoriesBySalesAlltime( int topSize )
    {
        List<String> result = new ArrayList<>( topSize );

        // === Get a database connection ===
        Connection con = DBConnectionPool.getMysqlConnection();

        // === Collect data from the database ===
        Map<String, Double> temp = new HashMap<>();

        final String command = "SELECT category, amount FROM purchase";
        try( PreparedStatement pstmt = con.prepareStatement( command );
             ResultSet rs = pstmt.executeQuery() )
        {
            while( rs.next() )
            {
                String category = rs.getString( 1 );
                Double amount = rs.getDouble( 2 );

                temp.put( category, amount + temp.getOrDefault( category, 0.0 ) );
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        // === Close the database connection ===
        DBConnectionPool.closeConnection( con );

        // Sort and return the results
        List<String> fullResults = ReportTools.sortMapByValuesDescending( temp );
        return ReportTools.createTopSalesAsList( topSize, fullResults );
    }


    public static List<String> getTopCategoriesBySalesForOneMonth( int topSize, int month, int year )
    {
        Map<String, Double> temp = ReportSqlQueries.getTotalSalesPerCategoryForOneMonth( month, year );

        List<String> fullResults = ReportTools.sortMapByValuesDescending( temp );

        return ReportTools.createTopSalesAsList( topSize, fullResults );
    }


    public static List<String> getTopCustomersBySalesForCurrentMonth( int topSize )
    {
        LocalDate today = LocalDate.now();

        return ReportSqlQueries.getTopCustomersBySalesForOneMonth( topSize,
                                                                   today.getMonthValue(),
                                                                   today.getYear() );
    }


    public static List<String> getTopCustomersBySalesForPreviousMonth( int topSize )
    {
        LocalDate previousMonth = LocalDate.now().minusMonths( 1 );

        return ReportSqlQueries.getTopCustomersBySalesForOneMonth( topSize,
                                                                   previousMonth.getMonthValue(),
                                                                   previousMonth.getYear() );
    }


    public static List<String> getTopCustomersBySalesForOneMonth( int topSize, int month, int year )
    {
        List<String> result = new ArrayList<>();

        // === Get a database connection ===
        Connection con = DBConnectionPool.getMysqlConnection();

        // === Collect data from the database ===
        Map<String, Double> temp = new HashMap<>();

        final String command = "SELECT customer.name, "
                                + "customer.surname, "
                                + "customer.email, "
                                + "customer.idCustomer, "
                                + "purchase.amount "
                                + "FROM customer "
                                + "JOIN cart ON cart.idCustomer = customer.idCustomer "
                                + "JOIN purchase ON purchase.idCustomer = customer.idCustomer "
                                + "AND purchase.idCart = cart.idCart "
                                + "WHERE MONTH(cart.date) = ? AND YEAR(cart.date) = ?";
        try( PreparedStatement pstmt = con.prepareStatement( command ) )
        {
            pstmt.setInt( 1, month );
            pstmt.setInt( 2, year );

            try( ResultSet rs = pstmt.executeQuery() )
            {
                while( rs.next() )
                {
                    String name = rs.getString( 1 );
                    String surname = rs.getString( 2 );
                    String email = rs.getString( 3 );
                    int idCustomerDB = rs.getInt( 4 );
                    Double amount = rs.getDouble( 5 );

                    String identity = surname.toUpperCase() + " " + name + " [#" + idCustomerDB + "]" + ":" + email;
                    temp.put(identity, amount + temp.getOrDefault(identity, 0.0));
                }
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        // === Close the database connection ===
        DBConnectionPool.closeConnection( con );

        // Sort and return the results
        List<String> fullResults = ReportTools.sortMapByValuesDescending( temp );
        return ReportTools.createTopSalesAsList( topSize, fullResults );
    }
}
