package databaseworker;


import actions.pdfworker.ReceiptPDFWriter;
import dataobjects.Cart;
import dataobjects.Payment;
import dataobjects.ProductCategory;
import dataobjects.Receipt;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class ReceiptSqlQueries
{
    /**
     * This method inserts a Receipt object into a database.
     * @param properReceipt a Receipt object
     * @param con a Connection to the database
     * @return the ID of the Receipt in the database if the operation was successful, or -1 otherwise
     */
    public static int insertReceiptIntoMysql( Receipt properReceipt, int idCartDB, Connection con )
    {
        int idReceiptDB = -1;

        // Prepare data for Receipt insertion into database, without its PDF format
        int idCustomerDB = ReceiptSqlQueries.getIDCustomerDB( idCartDB, con );

        Map<ProductCategory, Double> purchases = properReceipt.getCartFromDB().getPurchases();
        StringBuilder sbPurchases = new StringBuilder(  );
        for( ProductCategory category : purchases.keySet() )
        {
            sbPurchases.append( category.name().toLowerCase() )
                       .append( ":" ).append( purchases.get( category ) )
                       .append( ";" );
        }

        List<Payment> payments = properReceipt.getPaymentsFromDB();
        StringBuilder sbPayments = new StringBuilder();
        for( Payment p : payments )
        {
            sbPayments.append( p.getType().name().toLowerCase() )
                      .append( ":" ).append( p.getAmount() )
                      .append( ";" );
        }

        // Insert Receipt into database
        final String command = "INSERT INTO receipt (idCart, idCustomer, purchases, totalReceipt, payments)"
                                + "VALUES (?, ?, ?, ?, ?)";
        try( PreparedStatement pstmt = con.prepareStatement( command ) )
        {
            pstmt.setInt( 1, idCartDB );
            pstmt.setInt( 2, idCustomerDB );
            pstmt.setString( 3, sbPurchases.toString() );
            pstmt.setDouble( 4, properReceipt.computeTotalAmount() );
            pstmt.setString( 5, sbPayments.toString() );

            pstmt.executeUpdate();
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        // Prepare & add to database the PDF format of the Receipt just inserted
        idReceiptDB = ReceiptSqlQueries.getLatestInsertedReceiptIdFromDB( con );
        String pdfFilePath = ReceiptPDFWriter.write( properReceipt, idReceiptDB );
        ReceiptSqlQueries.updateReceiptPDFIntoMysql( idReceiptDB, pdfFilePath, con );

        return idReceiptDB;
    }


    /**
     * This method obtains the database ID of the Customer associated with a Receipt,
     * starting from the Cart associated with that Receipt.
     * @param idCartDB the database ID of the Cart
     * @param con a connection to the database
     * @return the idCustomerDB associated with a Receipt if successful, or -1 otherwise
     */
    private static int getIDCustomerDB( int idCartDB, Connection con )
    {
        int idCustomerDB = -1;

        final String command = "SELECT idCustomer FROM cart WHERE idCart = ?";
        try( PreparedStatement pstmt = con.prepareStatement( command ) )
        {
            pstmt.setInt( 1, idCartDB );

            try( ResultSet rs = pstmt.executeQuery() )
            {
                if( rs.next() )
                {
                    idCustomerDB = rs.getInt( 1 );
                }
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return idCustomerDB;
    }


    /**
     * This method returns the ID in the database of the last inserted Receipt.
     * @param con a database connection
     * @return the ID in the database of the latest Receipt inserted if successful, or -1 otherwise
     */
    public static int getLatestInsertedReceiptIdFromDB( Connection con )
    {
        int result = -1;

        final String command = "SELECT LAST_INSERT_ID();";
        try( PreparedStatement pstmt = con.prepareStatement( command ) )
        {
            try( ResultSet rs = pstmt.executeQuery() )
            {
                if( rs.next() )
                {
                    result = rs.getInt( 1 );
                }
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return result;
    }


    /**
     * This methods adds to the database a PDF associated with a Receipt.
     * @param idReceiptDB the Receipt ID in the database
     * @param filepath the path to the PDF file
     * @param con a connection to the database
     */
    public static void updateReceiptPDFIntoMysql( int idReceiptDB, String filepath, Connection con )
    {
        if( filepath != null && filepath.length() > 1 )
        {
            final String command = "UPDATE receipt SET pdfReceipt = ? WHERE idReceipt = ?";
            try( PreparedStatement pstmt = con.prepareStatement( command ) )
            {
                try( FileInputStream input = new FileInputStream( filepath ) )
                {
                    pstmt.setBlob( 1, input );
                    pstmt.setInt( 2, idReceiptDB );

                    pstmt.executeUpdate();
                }
                catch( IOException ioe )
                {
                    ioe.printStackTrace();
                }
            }
            catch( SQLException sqle )
            {
                sqle.printStackTrace();
            }
        }
        else
        {
            System.out.println( "Please provide the path to the PDF Receipt file." );
        }
    }


    /**
     * This method creates a Receipt object from data in the database.
     * @param idReceiptDB the ID of the desired Receipt in the database
     * @param con a Connection to the database
     * @return the Receipt object created if the operation is successful, or 'null' otherwise
     */
    public static Receipt getReceiptByIDFromMysql( int idReceiptDB, Connection con )
    {
        Receipt result = null;

        int idCartDb = ReceiptSqlQueries.getIDCartDB( idReceiptDB, con );
        Cart cartFromDB = CartSqlQueries.getCartFromMysql( idCartDb, con );
        List<Payment> paymentsFromDB = PaymentSqlQueries.getPaymentsByCartFromMysql( idCartDb, con );
        if( cartFromDB != null )
        {
            result = new Receipt( cartFromDB, paymentsFromDB );
        }

        return result;
    }


    /**
     * This method returns the file path to a receipt in PDF format loaded from the database.
     * @param idReceiptDB the ID of the desired Receipt in the database
     * @param con a Connection to the database
     * @return a string = the path to the PDF file if the operation is successful, or an empty string otherwise
     */
    public static String getReceiptPdfByIdFromMysql(int idReceiptDB, Connection con )
    {
        String result = "";

        final String command = "SELECT pdfReceipt FROM receipt WHERE idReceipt = ?";
        try( PreparedStatement pstmt = con.prepareStatement( command ) )
        {
            pstmt.setInt( 1, idReceiptDB );

            try( ResultSet rs = pstmt.executeQuery() )
            {
                LocalDate timestamp = LocalDate.now();
                String filepath = "Receipt #" + idReceiptDB + " (obtained " + timestamp + ").pdf";
                try( FileOutputStream output = new FileOutputStream( filepath ) )
                {
                    while( rs.next() )
                    {
                        InputStream input = rs.getBinaryStream("pdfReceipt");
                        byte[] buffer = new byte[2000];
                        if( input.read( buffer ) > 0 )
                        {
                            output.write( buffer );
                            output.flush();
                        }
                    }

                    result = filepath;
                }
                catch( IOException ioe )
                {
                    ioe.printStackTrace();
                }
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return result;
    }


    /**
     * This method obtains the database ID of the Cart associated with a Receipt.
     * @param idReceiptDb the database ID of the Receipt
     * @param con a connection to the database
     * @return the idCartDB associated with a Receipt if the operation is successful, or -1 otherwise
     */
    private static int getIDCartDB( int idReceiptDb, Connection con )
    {
        int idCartDB = -1;

        final String command = "SELECT idCart FROM receipt WHERE idReceipt = ?";
        try( PreparedStatement pstmt = con.prepareStatement( command ) )
        {
            pstmt.setInt( 1, idReceiptDb );

            try( ResultSet rs = pstmt.executeQuery() )
            {
                while( rs.next() )
                {
                    idCartDB = rs.getInt(1);
                }
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return idCartDB;
    }


    public static List<Integer> getIDsOfCartsWithoutReceipt( Connection con )
    {
        List<Integer> result = new ArrayList<>();

        final String command = "SELECT idCart"
                               + " FROM cart"
                               + " WHERE NOT EXISTS (SELECT idCart"
                                                     + " FROM receipt "
                                                     + " WHERE receipt.idCart = cart.idCart)";
        try( PreparedStatement pstmt = con.prepareStatement( command );
             ResultSet rs = pstmt.executeQuery() )
        {
            while( rs.next() )
            {
                result.add( rs.getInt( 1 ) );
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return result;
    }
}
