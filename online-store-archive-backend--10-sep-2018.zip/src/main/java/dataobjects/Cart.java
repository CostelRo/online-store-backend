package dataobjects;

import actions.strategy.CartStrategy;
import actions.strategy.DataObjectStrategy;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by CostelRo on 08.08.2018.
 */


/**
 * This class models a finalized cart (this is a requirement of the project).
 */
public class Cart
{
    // fields
    private static          int counter = 1;
    private static  final   DataObjectStrategy strategy = new CartStrategy();
    private         final   Integer idJava;
    private         final   Integer customerIDJava;
    private         final   LocalDate date;
    private         final   Map<ProductCategory, Double> purchases;


    // constructors
    public Cart( Integer customerIDJava, LocalDate date, Map<ProductCategory, Double> purchases )
    {
        this.idJava = counter;
        counter++;
        this.customerIDJava = customerIDJava;
        this.date = date;
        this.purchases = purchases;
    }


    // getters
    public DataObjectStrategy getStrategy()
    {
        return Cart.strategy;
    }

    public Integer getIdJava() { return this.idJava; }

    public Integer getCustomerIDJava() { return this.customerIDJava; }

    public LocalDate getDate()  { return this.date; }

    public Map<ProductCategory, Double> getPurchases() { return new HashMap<>( this.purchases ); }


    // other methods
    public static List<Object> parseFromCSVString( String line )
    {
        return Cart.strategy.parseObjectFromCSVString( line );
    }


    /**
     * This method writes a Cart object to a database.
     * @param cart the Cart object
     * @return int the ID of the Cart in the database if the operation was successful, or -1 otherwise
     */
    public static int writeToDatabase( Cart cart )
    {
        return Cart.strategy.writeObjectToDatabase( cart );
    }


    public Double computeTotalAmount()
    {
        Double result = 0.0;

        for( ProductCategory category : this.purchases.keySet() )
        {
            result += this.purchases.get( category );
        }

        return result;
    }


    @Override
    public String toString()
    {
        StringBuilder purchases = new StringBuilder("");
        for( ProductCategory category : this.purchases.keySet() )
        {
            purchases.append(" ").append( category.toString().toLowerCase() ).append( ": ")
                     .append( this.purchases.get( category ) ).append(";");
        }

        return "Cart #" + this.idJava + "for customer #" + this.customerIDJava
                + " (date: " + this.date.toString() + ") contains: "
                + purchases.toString();
    }
}
