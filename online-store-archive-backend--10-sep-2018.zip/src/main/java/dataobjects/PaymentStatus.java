package dataobjects;

/**
 * Created by CostelRo on 08.08.2018.
 */


public enum PaymentStatus
{
    PENDING,
    PROCESSED;
}
