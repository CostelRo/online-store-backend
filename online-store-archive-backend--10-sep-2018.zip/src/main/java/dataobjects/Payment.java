package dataobjects; /**
 * Created by CostelRo on 08.08.2018.
 */


import actions.strategy.DataObjectStrategy;
import actions.strategy.PaymentStrategy;

import java.util.List;

/**
 * This class models a finalized, processed, payment (this is a requirement of the project).
 */
public class Payment
{
    // fields
    private static          int counter = 1;
    private static  final   DataObjectStrategy strategy = new PaymentStrategy();
    private         final   Integer idJava;
    private         final   Integer cartIDJava;
    private         final   Integer customerIDJava;
    private         final   PaymentStatus status;
    private         final   PaymentType type;
    private         final   Double amount;


    // constructors
    public Payment( Integer cartIDJava, Integer customerIDJava, PaymentStatus status, PaymentType type, double amount )
    {
        this.idJava = counter;
        counter++;
        this.cartIDJava = cartIDJava;
        this.customerIDJava = customerIDJava;
        this.status = PaymentStatus.PROCESSED;
        this.type = type;
        this.amount = amount;
    }


    // getters
    public DataObjectStrategy getStrategy()
    {
        return Payment.strategy;
    }

    public Integer getIdJava() { return this.idJava; }

    public Integer getCartIDJava() { return this.cartIDJava; }

    public Integer getCustomerIDJava() { return this.customerIDJava; }

    public PaymentStatus getStatus() { return this.status; }

    public PaymentType getType() { return this.type; }

    public double getAmount() { return this.amount; }


    // other methods
    public static List<Object> parseFromCSVString( String line )
    {
        return Payment.strategy.parseObjectFromCSVString( line );
    }


    /**
     * This method writes a Payment object to a database.
     * @param payment the Payment object
     * @return int the ID of the Payment in the database if the operation was successful, or -1 otherwise
     */
    public static int writeToDatabase( Payment payment )
    {
        return Payment.strategy.writeObjectToDatabase( payment );
    }


    @Override
    public String toString()
    {
        return "Finalized payment #" + this.idJava + " (" + this.type.name().toLowerCase() + ")"
                + " from customer #" + this.customerIDJava + ", for cart #" + this.cartIDJava
                + ", value = " + this.amount;
    }
}
