package dataobjects;

import actions.strategy.CustomerStrategy;
import actions.strategy.DataObjectStrategy;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by CostelRo on 08.08.2018.
 */


public class Customer
{
    // fields
    private static         int counter = 1;
    private static  final  DataObjectStrategy strategy = new CustomerStrategy();
    private                Integer idJava;
    private                String name;
    private                String surname;
    private                String email;
    private                Set<Address> address;
    private                Set<Integer> buyingHistory;  // a set of Cart-object IDs


    // constructors
    public Customer( String name, String surname, String email, Address address )
    {
        this.idJava = counter;
        counter++;
        this.name = name;
        this.surname = surname;
        this.email = email;
        Set<Address> addresses = new HashSet<>();
        addresses.add( address );
        this.address = addresses;
        this.buyingHistory = new HashSet<>();
    }

    public Customer( String name, String surname, String email, Set<Address> addresses )
    {
        this.idJava = counter;
        counter++;
        this.name = name;
        this.surname = surname;
        this.email = email;
        this.address = addresses;
        this.buyingHistory = new HashSet<>();
    }

    public Customer( String name, String surname, String email, Set<Address> addresses, Set<Integer> buyingHistory )
    {
        this( name, surname, email, addresses );
        this.buyingHistory = buyingHistory;
    }

    public Customer( Customer customerToCopy )
    {
        if( customerToCopy != null )
        {
            this.idJava = counter;
            counter++;
            this.name = customerToCopy.getName();
            this.surname = customerToCopy.getSurname();
            this.email = customerToCopy.getEmail();
            this.address = customerToCopy.getAddress();
            this.buyingHistory = customerToCopy.getBuyingHistory();
        }
    }


    // getters and setters
    public DataObjectStrategy getStrategy()
    {
        return Customer.strategy;
    }

    public int getIdJava()
    {
        return this.idJava;
    }

    public String getName()
    {
        return this.name;
    }

    public void setName( String newName )
    {
        if( newName != null && newName.length() > 0 ) { this.name = newName.trim(); }
    }

    public String getSurname()
    {
        return this.surname;
    }

    public void setSurname( String newSurname )
    {
        if( newSurname != null && newSurname.length() > 0 ) { this.surname = newSurname.trim(); }
    }

    public String getEmail()
    {
        return this.email;
    }

    public void setEmail( String newEmail )
    {
        if( newEmail == null ) { return; }

        // simplest validity check: a valid email must contain at least 3 characters, e.g. "x@y"
        String trimmedEmail = newEmail.trim();
        if( trimmedEmail.length() >= 3 && checkEmailFormatValidity( trimmedEmail ) )
        {
            this.email = trimmedEmail;
        }
    }

    public Set<Address> getAddress()
    {
        return new HashSet<>( this.address );
    }

    public Set<Integer> getBuyingHistory()
    {
        return new HashSet<>( this.buyingHistory );
    }


    // other methods
    public static List<Object> parseFromCSVString( String line )
    {
        return Customer.strategy.parseObjectFromCSVString( line );
    }


    /**
     * This method writes a Customer object to a database, together with its included Address object(s).
     * @param customer the Customer object
     * @return int the ID of the Customer in the database if the operation was successful, or -1 otherwise
     */
    public static int writeToDatabase( Customer customer )
    {
        return Customer.strategy.writeObjectToDatabase( customer );
    }


    /**
     * The methods makes a very simplistic format validity check of the string representing an email address.
     * The rule used: the email string must contain 2 strings of characters non-'@' that have a "@" between them.
     * @return 'true' if the email string has a valid format, 'false' otherwise
     */
    private static boolean checkEmailFormatValidity( String email )
    {
        boolean isAmpersandPlacedProperly = !email.startsWith("@") && !email.endsWith("@");
        boolean isAmpersandUsedOnce = ( email.indexOf("@") == email.lastIndexOf("@") );

        return isAmpersandPlacedProperly && isAmpersandUsedOnce;
    }


    public void addAddress( Address newAddress )
    {
        if( newAddress != null )
        {
            this.address.add( newAddress );
        }
    }


    public void addToBuyingHistoryByCart( Cart newCart )
    {
        if( newCart != null )
        {
            this.buyingHistory.add( newCart.getIdJava() );
        }
        else
        {
            System.out.println( "Operation not executed. Insert a proper Cart!" );
        }
    }


    public void addToBuyingHistoryByCartID( int idCartDB )
    {
        if( idCartDB > 0 )
        {
            this.buyingHistory.add( idCartDB );
        }
        else
        {
            System.out.println( "Operation not executed. Insert a Cart-ID larger than 0!" );
        }
    }


    @Override
    public String toString()
    {
        int counter = 1;
        StringBuffer addressesAsString = new StringBuffer();
        for( Address address : this.address )
        {
            addressesAsString.append(" (address ").append(counter).append(": ").append(address.toString()).append(")");
            counter++;
        }

        StringBuilder cartsInBuyingHistory = new StringBuilder(" -- carts:");
        for( int cartID : this.buyingHistory )
        {
            cartsInBuyingHistory.append(" #").append( cartID );
        }

        return "Customer: " + this.surname.toUpperCase() + " " + this.name
                + ", " + this.email + addressesAsString.toString()
                + cartsInBuyingHistory.toString() + ".";
    }
}
