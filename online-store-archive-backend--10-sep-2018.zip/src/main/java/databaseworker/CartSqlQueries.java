package databaseworker;

import actions.strategy.CartStrategy;
import dataobjects.Cart;
import dataobjects.ProductCategory;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;


/**
 * Created by CostelRo on 17.08.2018.
 */


public final class CartSqlQueries
{
    /**
     * This method inserts a Cart object into a database.
     * @param properCart a Cart object (contains the database ID of the customer it is related to!)
     * @param connectionToMysql a Connection object to the database
     * @return the ID of the Cart in the database if the operation was successful, or -1 otherwise
     * NOTE: A finalized Cart and its related finalized Payment(s), like we are keeping in our backend,
     * are logically connected (although the Payments are not part of the Cart).
     * Because of this, adding a Cart should automatically continue with the addition of its connected Payment(s).
     */
    public static int insertCartIntoMysql( Cart properCart, Connection connectionToMysql )
    {
        int idCartDB = -1;

        final String command = "INSERT INTO cart (idCustomer, date) VALUES (?, ?)";
        try( PreparedStatement pstmt = connectionToMysql.prepareStatement( command ) )
        {
            // the idCustomer is a proper idCustomerDB
            int idCustomerDB = properCart.getCustomerIDJava();

            pstmt.setInt( 1, idCustomerDB );
            pstmt.setDate( 2, Date.valueOf( properCart.getDate() ) );
            pstmt.executeUpdate();

            // insert the purchases information from this Cart object
            idCartDB = CartSqlQueries.getLatestUsedID( connectionToMysql );

            if( idCartDB > 0 )
            {
                for( ProductCategory category : properCart.getPurchases().keySet() )
                {
                    String product = category.name().toLowerCase();
                    double amount = properCart.getPurchases().get( category );
                    CartSqlQueries.insertPurchaseIntoMysql( idCartDB, idCustomerDB, product, amount, connectionToMysql );
                }
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return idCartDB;
    }


    /**
     * This method inserts the purchases information from inside a Cart object into the database.
     * @param category the product category name of a purchase from the Cart object
     * @param amount the purchase value for the current product category
     * @param idCartDB the Cart to which this purchase object belongs
     * @param idCustomerDB the Customer to which this purchase object belongs
     * @param connectionToMysql a Connection object to the database
     */
    private static void insertPurchaseIntoMysql( int idCartDB, int idCustomerDB,
                                                 String category, double amount,
                                                 Connection connectionToMysql )
    {
        final String command = "INSERT INTO purchase (idCart, idCustomer, category, amount) " +
                               "VALUES (?, ?, ?, ?)";
        try( PreparedStatement pstmt = connectionToMysql.prepareStatement( command ) )
        {
            pstmt.setInt( 1, idCartDB );
            pstmt.setInt( 2, idCustomerDB );
            pstmt.setString( 3, category );
            pstmt.setDouble( 4, amount );
            pstmt.executeUpdate();
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }
    }


    /**
     * This method returns the ID in the database of the last inserted Cart.
     * @param con a Connection object to the database
     * @return the ID of the Cart from the database if the operation is successful, or -1 otherwise
     */
    private static int getLatestUsedID( Connection con )
    {
        int idCartDB = -1;

        final String command = "SELECT MAX(idCart) FROM cart";
        try( PreparedStatement pstmt = con.prepareStatement( command ) )
        {
            ResultSet resultSet = pstmt.executeQuery();
            if( resultSet.next() )
            {
                idCartDB = resultSet.getInt(1);
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return idCartDB;
    }


    /**
     * This method creates a Cart object from data in the database.
     * @param idCart the ID of the desired Cart in the database
     * @param connectionToMysql a Connection object to the database
     * @return the Cart object created if the operation is successful, or -1 otherwise
     */
    public static Cart getCartFromMysql( int idCart, Connection connectionToMysql )
    {
        Cart result = null;

        final String command = "SELECT cart.idCustomer, cart.date, purchase.category, purchase.amount"
                               + " FROM cart JOIN purchase ON cart.idCart = purchase.idCart"
                               + " WHERE cart.idCart = ?";
        try( PreparedStatement pstmt = connectionToMysql.prepareStatement( command ) )
        {
            pstmt.setInt( 1, idCart );
            ResultSet resultSet = pstmt.executeQuery();

            // a Cart may contain more than one pair of values (category, amount)
            int idCustomer = -1;
            LocalDate date = null;
            Map<ProductCategory, Double> purchases = new HashMap<>();
            while( resultSet.next() )
            {
                idCustomer = resultSet.getInt( "cart.idCustomer" );
                date = resultSet.getDate( "cart.date" ).toLocalDate();
                String categoryAsString = resultSet.getString( "purchase.category" );
                ProductCategory category = CartStrategy.getProductCategory( categoryAsString );
                Double amount = resultSet.getDouble( "purchase.amount" );
                purchases.put( category, amount );
            }

            if( idCustomer > 0 && date != null )
            {
                result = new Cart( idCustomer, date, purchases );
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return result;
    }


    public static void filterCartsFromMysql( Cart cartModel, Connection connectionToMqsql )
    {
        // TODO
        // String command = "SELECT ? FROM ?,... WHERE ?, ? ORDER BY";
        // ResultSet results = con.executeQuery( command );
        // while( results.next() )   // this automatically moves to the next row within the ResultSet
        // {
        //     String s = results.getString( "columnNameFromResultset" );
        //     int i = results.getInt( columnIDFromResultset ); -- column-IDs start from 1 !
        //     ... getDouble etc.
        // }
    }
}
