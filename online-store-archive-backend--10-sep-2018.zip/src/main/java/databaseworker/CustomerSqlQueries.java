package databaseworker;


import dataobjects.Address;
import dataobjects.Customer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;


public final class CustomerSqlQueries
{
    /**
     * This method inserts a Customer object into the database.
     * @param customer a Customer object
     * @param connectionToMysql a Connection object to the database
     * @return the ID of the Customer in the database if the operation was successful, or -1 otherwise
     */
    public static int insertCustomerIntoMysql( Customer customer, Connection connectionToMysql )
    {
        int idCustomerDB = -1;

        // insert the Customer object
        String name = customer.getName();
        String surname = customer.getSurname();
        String email = customer.getEmail();
        final String sqlCommand = "INSERT INTO customer (name, surname, email) " +
                                  "VALUES (?, ?, ?)";

        try( PreparedStatement pstmt = connectionToMysql.prepareStatement( sqlCommand,
                                                                           PreparedStatement.RETURN_GENERATED_KEYS ) )
        {
            pstmt.setString( 1, name );
            pstmt.setString( 2, surname );
            pstmt.setString( 3, email );
            pstmt.executeUpdate();

            // get the ID of the Customer just inserted in the database
            ResultSet generatedKeys = pstmt.getGeneratedKeys();
            if( generatedKeys != null && generatedKeys.next() )
            {
                idCustomerDB = generatedKeys.getInt( 1 );
            }

            // insert the Address objects from this Customer object
            if( idCustomerDB > 0 )
            {
                for( Address address : customer.getAddress() )
                {
                    CustomerSqlQueries.insertAddressIntoMysql( address, idCustomerDB, connectionToMysql);
                }
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return idCustomerDB;
    }


    /**
     * This method inserts an Address object into the database.
     * @param address an Address object to the database
     * @param idCustomer the Customer to which this Address object belongs
     * @param connectionToMysql a Connection object
     * @return int the number of addresses inserted in the database if successful, or -1 otherwise
     */
    public static int insertAddressIntoMysql( Address address, int idCustomer, Connection connectionToMysql )
    {
        int result = -1;

        String country = address.getCountry();
        String locality = address.getLocality();
        String street = address.getStreet();
        String number = address.getNumber();
        final String command = "INSERT INTO address ( idCustomer, country, locality, street, number) " +
                               "VALUES (?, ?, ?, ?, ?)";
        try( PreparedStatement pstmt = connectionToMysql.prepareStatement( command ) )
        {
            pstmt.setInt( 1, idCustomer );
            pstmt.setString( 2, country );
            pstmt.setString( 3, locality );
            pstmt.setString( 4, street );
            pstmt.setString( 5, number );
            result = pstmt.executeUpdate();
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return result;
    }


    /**
     * This method creates a Customer object from data fetched from the database.
     * @param idCustomer the ID of the desired Customer in the database
     * @param connectionToMysql a Connection object to the database
     * @return the Customer object created if the operation is successful, or -1 otherwise
     */
    public static Customer getCustomerFromMysql( int idCustomer, Connection connectionToMysql )
    {
        Customer result = null;

        final String command = "SELECT * FROM customer WHERE idCustomer = ?";
        try( PreparedStatement pstmt = connectionToMysql.prepareStatement( command ) )
        {
            pstmt.setInt( 1, idCustomer );
            ResultSet resultSet = pstmt.executeQuery();
            if( resultSet.next() )
            {
                String name = resultSet.getString( "name" );
                String surname = resultSet.getString( "surname" );
                String email = resultSet.getString( "email" );
                Address address = CustomerSqlQueries.getAddressFromMysql( idCustomer, connectionToMysql );

                result = new Customer( name, surname, email, address );
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return result;
    }


    /**
     * This method creates an Address object from data fetched from the database.
     * @param idCustomer the ID in the database of the Customer to which this Address object belongs
     * @param connectionToMysql a Connection object to the database
     * @return the Address object created if the operation is successful, or -1 otherwise
     */
    public static Address getAddressFromMysql( int idCustomer, Connection connectionToMysql )
    {
        Address result = null;

        final String command = "SELECT * FROM address WHERE idCustomer = ?";
        try( PreparedStatement pstmt = connectionToMysql.prepareStatement( command ) )
        {
            pstmt.setInt( 1, idCustomer );
            ResultSet resultSet = pstmt.executeQuery();
            if( resultSet.next() )
            {
                String country = resultSet.getString( "country" );
                String locality = resultSet.getString( "locality" );
                String street = resultSet.getString( "street" );
                String number = resultSet.getString( "number" );

                result = new Address( country, locality, street, number );
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return result;
    }


    /**
     * This method return data required to created a Customer object by some Java client code
     * from data loaded from the database.
     * @param idCustomerDB the database ID of the requested customer
     * @param connectionToMqsql a connection to the database
     * @return a list of data
     */
    public static Map<Integer, List<String>> getOneCustomerDataByIDFromMysql( int idCustomerDB,
                                                                              Connection connectionToMqsql )
    {
        Set<Integer> tempIdCustomerDB = new HashSet<>( 1 );
        tempIdCustomerDB.add( idCustomerDB );

        return CustomerSqlQueries.getCustomersDataByIDFromMysql( tempIdCustomerDB, connectionToMqsql );
    }


    /**
     * This method return data required to created Customer objects by some Java client code
     * from data loaded from the database.
     * @param idCustomersDB a set of database IDs of the requested customer
     * @param connectionToMqsql a connection to the database
     * @return a Map of lists of String objects
     */
    public static Map<Integer, List<String>> getCustomersDataByIDFromMysql( Set<Integer> idCustomersDB,
                                                                            Connection connectionToMqsql )
    {
        Map<Integer, List<String>> result = new HashMap<>();

        // creating the SQL query string
        String customerIDs = "";
        if( idCustomersDB != null && idCustomersDB.size() > 0 )
        {
            List<Integer> tempSourceIDs = new ArrayList<>( idCustomersDB );
            StringBuilder sb = new StringBuilder( "WHERE " );
            for ( int i=0; i < tempSourceIDs.size(); i++ )
            {
                sb.append( "customer.idCustomer = " ).append( tempSourceIDs.get( i ) );
                if( i < tempSourceIDs.size() - 1 )
                {
                    sb.append( " OR " );
                }
            }
            sb.append( " ORDER BY customer.idCustomer ASC" );
            customerIDs = sb.toString();
        }
        String command = "SELECT customer.idCustomer, customer.name, customer.surname, customer.email, "
                              + "address.country, address.locality, address.street, address.number, "
                              + "cart.idCart "
                       + "FROM customer "
                            + "JOIN address ON address.idCustomer = customer.idCustomer "
                            + "JOIN cart ON cart.idCustomer = customer.idCustomer "
                       + customerIDs;

        // executing the SQL query & collecting the data
        try( PreparedStatement pstmt = connectionToMqsql.prepareStatement( command ) )
        {
            ResultSet rs = pstmt.executeQuery( command );
            int tempMapKey = 0;
            while( rs.next() )
            {
                int idCustomerDB = rs.getInt( "customer.idCustomer" );
                String idCustomerDBAsString = String.valueOf( idCustomerDB );
                String name = rs.getString( "customer.name" );
                String surname = rs.getString( "customer.surname" );
                String email = rs.getString( "customer.email" );
                String country = rs.getString( "address.country" );
                String locality = rs.getString( "address.locality" );
                String street = rs.getString( "address.street" );
                String number = rs.getString( "address.number" );
                int idCartDB = rs.getInt( "cart.idCart" );
                String idCartDBAsString = String.valueOf( idCartDB );

                List<String> currentResult = new ArrayList<>();
                Collections.addAll( currentResult,
                                    idCustomerDBAsString, name, surname, email,
                                    country, locality, street, number,
                                    idCartDBAsString );
                result.put( tempMapKey, currentResult );
                tempMapKey++;
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return result;
    }
}
