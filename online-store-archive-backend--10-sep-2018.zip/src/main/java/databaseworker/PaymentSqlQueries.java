package databaseworker;

import actions.strategy.PaymentStrategy;
import dataobjects.Cart;
import dataobjects.Payment;
import dataobjects.PaymentStatus;
import dataobjects.PaymentType;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public final class PaymentSqlQueries
{
    /**
     * This method inserts a Payment object into the database.
     * A finalized Cart and its related finalized Payment(s), like we are keeping in our backend,
     * are always logically connected (although the Payments cannot be part of the Cart).
     * Because of this, adding a Cart should automatically continue with the addition of its connected Payment(s).
     * @param properPayment a Payment object (created in Java, associated with a Cart already in the database)
     *                      and containing the correct database IDs for its associated Cart and Customer
     * @param connectionToMysql a Connection object to the database
     * @return the ID of the Payment in the database if the operation was successful, or -1 otherwise
     */
    public static int insertPaymentIntoMysql( Payment properPayment, Connection connectionToMysql )
    {
        // TODO don't insert duplicate entries

        int idPayment = -1;

        // get the ID in the database of the Customer and the Cart connected to this Payment
        int idCartDB = properPayment.getCartIDJava();           // it's an idCartDB, from the CSVArchiveImporter
        int idCustomerDB = properPayment.getCustomerIDJava();   // it's an idCustomerDB, from the CSVArchiveImporter

        // insert the Payment object
        String status = properPayment.getStatus().name().toLowerCase();
        String type = properPayment.getType().name().toLowerCase();
        double amount = properPayment.getAmount();
        final String command = "INSERT INTO payment (idCart, idCustomer, status, type, amount) " +
                               "VALUES (?, ?, ?, ?, ?)";
        try( PreparedStatement pstmt = connectionToMysql.prepareStatement( command ) )
        {
            pstmt.setInt( 1, idCartDB );
            pstmt.setInt( 2, idCustomerDB );
            pstmt.setString( 3, status );
            pstmt.setString( 4, type );
            pstmt.setDouble( 5, amount );
            pstmt.executeUpdate();
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return idPayment;
    }


    /**
     * This method discovers the ID in the database of a Cart.
     * @param idCartDB the database ID of a Cart
     * @param con a connection to the database
     * @return the database CustomerID associated with the Cart if successful, -1 otherwise
     */
    public static int getCustomerID( int idCartDB, Connection con )
    {
        int result = -1;

        final String command = "SELECT idCustomer FROM cart WHERE idCart = ?";
        try ( PreparedStatement pstmt = con.prepareStatement( command ) )
        {
            pstmt.setInt( 1, idCartDB );
            ResultSet resultSet = pstmt.executeQuery();
            result = resultSet.getInt( 1 );
        } catch ( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return result;
    }


    /**
     * This method creates a Payment object from data in the database.
     * @param idPaymentDB the ID of the desired Payment in the database
     * @param connectionToMysql a Connection object to the database
     * @return the Payment object created if the operation is successful, or -1 otherwise
     */
    public static Payment getPaymentByIDFromMysql( int idPaymentDB, Connection connectionToMysql )
    {
        Payment result = null;

        final String command = "SELECT idCart, idCustomer, status, type, amount FROM payment WHERE idPayment = ?";
        try( PreparedStatement pstmt = connectionToMysql.prepareStatement( command ) )
        {
            pstmt.setInt( 1, idPaymentDB );
            ResultSet resultSet = pstmt.executeQuery();

            while( resultSet.next() )
            {
                int idCartB = resultSet.getInt( "idCart" );
                int idCustomerDB = resultSet.getInt( "idCustomer" );
                PaymentStatus status = PaymentStrategy.getPaymentStatus( resultSet.getString("status") );
                PaymentType type = PaymentStrategy.getPaymentType( resultSet.getString("type") );
                double amount = resultSet.getDouble( "amount" );

                result = new Payment(idCartB, idCustomerDB, status, type, amount);
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return result;
    }


    /**
     * This method gets all Payment associated to a Cart in the database.
     * @param idCartDB the database ID of the Cart to which the desired Payment is associated
     * @param connectionToMysql a Connection object to the database
     * @return a List of Payment objects
     */
    public static List<Payment> getPaymentsByCartFromMysql( int idCartDB, Connection connectionToMysql )
    {
        List<Payment> result = new ArrayList<>();

        final String command = "SELECT idCustomer, status, type, amount FROM payment WHERE idCart = ?";
        try( PreparedStatement pstmt = connectionToMysql.prepareStatement( command ) )
        {
            pstmt.setInt( 1, idCartDB );
            ResultSet resultSet = pstmt.executeQuery();

            while( resultSet.next() )
            {
                int idCustomerDB = resultSet.getInt( "idCustomer" );
                PaymentStatus status = PaymentStrategy.getPaymentStatus( resultSet.getString("status") );
                PaymentType type = PaymentStrategy.getPaymentType( resultSet.getString("type") );
                double amount = resultSet.getDouble( "amount" );

                Payment newPayment = new Payment( idCartDB, idCustomerDB, status, type, amount );
                result.add( newPayment );
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return result;
    }


    public static void filterCartsFromMysql( Cart cartModel, Connection connectionToMqsql )
    {
        // TODO
        // String command = "SELECT ? FROM ?,... WHERE ?, ? ORDER BY";
        // ResultSet results = con.executeQuery( command );
        // while( results.next() )   // this automatically moves to the next row within the ResultSet
        // {
        //     String s = results.getString( "columnNameFromResultset" );
        //     int i = results.getInt( columnIDFromResultset ); -- column-IDs start from 1 !
        //     ... getDouble etc.
        // }
    }
}
