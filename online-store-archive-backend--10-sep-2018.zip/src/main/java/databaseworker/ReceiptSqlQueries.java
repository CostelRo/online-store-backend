package databaseworker;


import actions.pdfworker.ReceiptPDFWriter;
import dataobjects.Cart;
import dataobjects.Payment;
import dataobjects.ProductCategory;
import dataobjects.Receipt;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class ReceiptSqlQueries
{
    /**
     * This method inserts a Receipt object into a database.
     * @param properReceipt a Receipt object
     * @param connectionToMysql a Connection object to the database
     * @return the ID of the Receipt in the database if the operation was successful, or -1 otherwise
     */
    public static int insertReceiptIntoMysql( Receipt properReceipt, int idCartDB, Connection connectionToMysql )
    {
        int idReceiptDB = -1;

        // prepare data for Receipt insertion into database, without its PDF format
        int idCustomerDB = ReceiptSqlQueries.getIDCustomerDB( idCartDB, connectionToMysql );

        Map<ProductCategory, Double> purchases = properReceipt.getCartFromDB().getPurchases();
        StringBuilder sbPurchases = new StringBuilder(  );
        for( ProductCategory category : purchases.keySet() )
        {
            sbPurchases.append( category.name().toLowerCase() )
                       .append( ":" ).append( purchases.get( category ) )
                       .append( ";" );
        }

        List<Payment> payments = properReceipt.getPaymentsFromDB();
        StringBuilder sbPayments = new StringBuilder();
        for( Payment p : payments )
        {
            sbPayments.append( p.getType().name().toLowerCase() )
                      .append( ":" ).append( p.getAmount() )
                      .append( ";" );
        }

        // insert Receipt into database
        final String command = "INSERT INTO receipt (idCart, idCustomer, purchases, totalReceipt, payments)"
                                + "VALUES (?, ?, ?, ?, ?)";
        try( PreparedStatement pstmt = connectionToMysql.prepareStatement( command ) )
        {
            pstmt.setInt( 1, idCartDB );
            pstmt.setInt( 2, idCustomerDB );
            pstmt.setString( 3, sbPurchases.toString() );
            pstmt.setDouble( 4, properReceipt.computeTotalAmount() );
            pstmt.setString( 5, sbPayments.toString() );

            pstmt.executeUpdate();

//            System.out.println("Receipt inserted into database.");
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        // prepare & add the PDF format of the Receipt just inserted
        idReceiptDB = ReceiptSqlQueries.getLatestInsertedReceiptIdFromDB( connectionToMysql );
        String pdfFilePath = ReceiptPDFWriter.write( properReceipt, idReceiptDB );
        ReceiptSqlQueries.updateReceiptPDFIntoMysql( idReceiptDB, pdfFilePath, connectionToMysql );

        return idReceiptDB;
    }


    /**
     * This method obtains the database ID of the Customer associated with a Receipt
     * starting from the Cart associated with that Receipt.
     * @param idCartDB the database ID of the Cart
     * @param connectionToMysql a connection to the database
     * @return the idCustomerDB associated with a Receipt if successful, or -1 otherwise
     */
    private static int getIDCustomerDB( int idCartDB, Connection connectionToMysql )
    {
        int idCustomerDB = -1;

        String command = "SELECT idCustomer FROM cart WHERE idCart = ?";
        try( PreparedStatement pstmt = connectionToMysql.prepareStatement( command ) )
        {
            pstmt.setInt( 1, idCartDB );
            ResultSet rs = pstmt.executeQuery();

            if( rs.next() )
            {
                idCustomerDB = rs.getInt( 1 );
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return idCustomerDB;
    }


    /**
     * This method returns the ID in the database of the last inserted Receipt.
     * @param con a database connection
     * @return the ID in the database of the latest Receipt inserted if successful, or -1 otherwise
     */
    public static int getLatestInsertedReceiptIdFromDB( Connection con )
    {
        int result = -1;

        final String command = "SELECT LAST_INSERT_ID();";
        try( PreparedStatement pstmt = con.prepareStatement( command ) )
        {
            try( ResultSet rs = pstmt.executeQuery() )
            {
                if ( rs.next() )
                {
                    result = rs.getInt( 1 );
                }
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return result;
    }


    /**
     * This methods adds to the database a PDF associated with a Receipt.
     * @param idReceiptDB the Receipt ID in the database
     * @param filepath the path to the PDF file
     * @param connectionToMysql a connection to the database
     */
    public static void updateReceiptPDFIntoMysql( int idReceiptDB, String filepath, Connection connectionToMysql )
    {
        final String command = "UPDATE receipt SET pdfReceipt = ? WHERE idReceipt = ?";
        try( PreparedStatement pstmt = connectionToMysql.prepareStatement( command ) )
        {
            File file = new File( filepath );
            if( file.exists() )
            {
                try ( FileInputStream input = new FileInputStream( file ) )
                {
                    pstmt.setBlob(1, input);
                    pstmt.setInt(2, idReceiptDB);
                    int updateResult = pstmt.executeUpdate();
                } catch (IOException ioe)
                {
                    ioe.printStackTrace();
                }
            }
            else
            {
                System.out.println( "Error: Receipt PDF file missing." );
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }
    }


    /**
     * This method creates a Receipt object from data in the database.
     * @param idReceiptDB the ID of the desired Receipt in the database
     * @param connectionToMysql a Connection object to the database
     * @return the Receipt object created if the operation is successful, or 'null' otherwise
     */
    public static Receipt getReceiptByIDFromMysql( int idReceiptDB, Connection connectionToMysql )
    {
        Receipt result = null;

        int idCartDb = ReceiptSqlQueries.getIDCartDB( idReceiptDB, connectionToMysql );
        Cart cartFromDB = CartSqlQueries.getCartFromMysql( idCartDb, connectionToMysql );
        List<Payment> paymentsFromDB = PaymentSqlQueries.getPaymentsByCartFromMysql( idCartDb, connectionToMysql );
        if( cartFromDB != null )
        {
            result = new Receipt( cartFromDB, paymentsFromDB );
        }

        return result;
    }


    /**
     * This method returns the file path to a receipt in PDF format loaded from the database.
     * @param idReceiptDB the ID of the desired Receipt in the database
     * @param connectionToMysql a Connection object to the database
     * @return a string = the path to the PDF file if the operation is successful, or an empty string otherwise
     */
    public static String getReceiptPDFByIdFromMysql( int idReceiptDB, Connection connectionToMysql )
    {
        String result = "";

        final String command = "SELECT pdfReceipt FROM receipt WHERE idReceipt = ?";
        try( PreparedStatement pstmt = connectionToMysql.prepareStatement( command ) )
        {
            pstmt.setInt( 1, idReceiptDB );
            ResultSet rs = pstmt.executeQuery();

            while( rs.next() )
            {
                LocalDate timestamp = LocalDate.now();
                String filepath = "Receipt #" + idReceiptDB + " (obtained " + timestamp + ").pdf";
                File receiptPDFFromDB = new File( filepath );
                try( FileOutputStream output = new FileOutputStream( receiptPDFFromDB ) )
                {
                    InputStream input = rs.getBinaryStream( "pdfReceipt" );
                    byte[] buffer = new byte[2000];
                    while( input.read( buffer ) > 0 )
                    {
                        output.write( buffer );
                    }

                    result = filepath;
                }
                catch( IOException ioe )
                {
                    ioe.printStackTrace();
                }
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return result;
    }


    /**
     * This method obtains the database ID of the Cart associated with a Receipt
     * @param idReceiptDb the database ID of the Receipt
     * @param connectionToMysql a connection to the database
     * @return the idCartDB associated with a Receipt if the operation is successful, or -1 otherwise
     */
    private static int getIDCartDB( int idReceiptDb, Connection connectionToMysql )
    {
        int idCartDB = -1;

        String command = "SELECT idCart FROM receipt WHERE idReceipt = ?";
        try( PreparedStatement pstmt = connectionToMysql.prepareStatement( command ) )
        {
            pstmt.setInt( 1, idReceiptDb );
            ResultSet rs = pstmt.executeQuery();

            while( rs.next() )
            {
                idCartDB = rs.getInt( 1 );
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return idCartDB;
    }


    public static List<Integer> getIDsOfCartsWithoutReceipt( Connection connectionToMysql )
    {
        List<Integer> result = new ArrayList<>();

        final String command = "SELECT idCart"
                               + " FROM cart"
                               + " WHERE NOT EXISTS (SELECT idCart"
                                                     + " FROM receipt "
                                                     + " WHERE receipt.idCart = cart.idCart)";
        try( PreparedStatement pstmt = connectionToMysql.prepareStatement( command ) )
        {
            ResultSet rs = pstmt.executeQuery();
            while( rs.next() )
            {
                result.add( rs.getInt( 1 ) );
            }
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }

        return result;
    }




    // Daniel:
    // - write separate search-methods for each type of search (by name, by title, by date etc.),
    // - and combine them if required.

    public static void filterReceiptsFromMysql( Receipt receiptModel, Connection connectionToMqsql )
    {
        // TODO
        // String command = "SELECT ? FROM ?,... WHERE ?, ? ORDER BY";
        // ResultSet results = con.executeQuery( command );
        // while( results.next() )   // this automatically moves to the next row within the ResultSet
        // {
        //     String s = results.getString( "columnNameFromResultset" );
        //     int i = results.getInt( columnIDFromResultset ); -- column-IDs start from 1 !
        //     ... getDouble etc.
        // }
    }
}
