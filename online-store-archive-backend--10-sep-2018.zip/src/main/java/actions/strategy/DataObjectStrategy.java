package actions.strategy;

import java.sql.Connection;
import java.util.List;

/**
 * Created by CostelRo on 15.08.2018.
 */


public interface DataObjectStrategy
{
    // fields
    String CSV_HEADER_START       = "=";  // set in our project
    String CSV_TOKENS_SEPARATOR   = "|";  // set in our project
    String REGEX_TOKENS_SEPARATOR = "\\" + DataObjectStrategy.CSV_TOKENS_SEPARATOR;


    // methods
    List<Object> parseObjectFromCSVString( String line );

    int writeObjectToDatabase( Object object );

    Object readObjectFromDatabase( int idOfObject, Connection con );

    boolean isValidLine( String line );
}
