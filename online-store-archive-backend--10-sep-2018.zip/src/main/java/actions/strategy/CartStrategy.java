package actions.strategy;

import databaseworker.CartSqlQueries;
import databaseworker.DBConnectionPool;
import dataobjects.Cart;
import dataobjects.ProductCategory;

import java.sql.Connection;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by CostelRo on 16.08.2018.
 */


public final class CartStrategy implements DataObjectStrategy
{
    public static ProductCategory getProductCategory( String source )
    {
        ProductCategory result;

        switch( source )
        {
            case "books":
                result = ProductCategory.BOOKS;
                break;
            case "computers":
                result = ProductCategory.COMPUTERS;
                break;
            case "clothes":
                result = ProductCategory.CLOTHES;
                break;
            case "furniture":
                result = ProductCategory.FURNITURE;
                break;
            case "mobiles":
                result = ProductCategory.MOBILES;
                break;
            case "toys":
                result = ProductCategory.TOYS;
                break;
            case "tv":
                result = ProductCategory.TV;
                break;
            default:
                result = null;
                break;
        }

        return result;
    }


    /**
     * This method parses a String and creates a Cart object from that data.
     * @param line the text of each valid line from a CSV file
     * @return a List of objects containing, in order:
     *              - the Cart ID from the CSV archive, referenced by other objects in the archive;
     *              - the Cart object.
     */
    @Override
    public List<Object> parseObjectFromCSVString( String line )
    {
        String[] source = line.split( DataObjectStrategy.REGEX_TOKENS_SEPARATOR );

        // only used to correlate with other data in the CSV archive
        Integer idCartCSV = Integer.valueOf( source[0] );
        Integer idCustomerCSV = Integer.valueOf( source[1] );

        String dateSource = source[2];
        String[] splitDateSource = dateSource.split( "-" );    // for date as: "Year-monthNumber-dayNumber"
        LocalDate date = LocalDate.of( Integer.parseInt( splitDateSource[0] ),
                                       Integer.parseInt( splitDateSource[1] ),
                                       Integer.parseInt( splitDateSource[2] ) );

        // get the pairs of (ProductCategory, amount) from the source data; valid lines contain at least 1 such a pair
        Map<ProductCategory, Double> purchases = new HashMap<>();
        int indexOfCurrentPurchase = 3;
        while( indexOfCurrentPurchase < source.length-1 )
        {
            purchases.put( getProductCategory( source[indexOfCurrentPurchase] ),
                           Double.parseDouble( source[indexOfCurrentPurchase+1] ) );
            indexOfCurrentPurchase += 2;
        }

        List<Object> result = new ArrayList<>(2);
        result.add( idCartCSV );
        result.add( new Cart( idCustomerCSV, date, purchases ) );

        return result;
    }


    /**
     * This method checks whether a string contains all the valid data needed to create a Cart object.
     * This is intended to be used when working with CSV files in this project.
     * This is intended to be used mainly by the CSVParser class and other clients close to the original source of data.
     * @param line the String used as a source of data
     * @return boolean 'true' if the source has all the proper data, 'false' otherwise
     */
    @Override
    public boolean isValidLine( String line )
    {
        // TODO, together with validation for each field from the CSV line
        return true;
    }


    /**
     * This method writes a Cart object to a database.
     * @param object the Cart object
     * @return int the ID of the Cart in the database if the operation was successful, or -1 otherwise
     */
    @Override
    public int writeObjectToDatabase( Object object )
    {
        int result = -1;

        if( (object != null) && (object instanceof Cart) )
        {
            Connection con = DBConnectionPool.getMysqlConnection();

            if( con != null )
            {
                result = CartSqlQueries.insertCartIntoMysql( (Cart) object, con );
                DBConnectionPool.closeConnection( con );
            }
            else
            {
                System.out.println( "[cart1] Error: connection unavailable, try again!" );
            }
        }

        return result;
    }


    /**
     * This method reads data from the database and creates a Cart object.
     * @param idOfObject the ID of the Cart in the database
     * @param con a database connection
     */
    @Override
    public Cart readObjectFromDatabase( int idOfObject, Connection con )
    {
        Cart result = null;

        con = DBConnectionPool.getMysqlConnection();
        if( con != null )
        {
            result = CartSqlQueries.getCartFromMysql( idOfObject, con );
            DBConnectionPool.closeConnection( con );
        }
        else
        {
            System.out.println( "[cart2] Error: connection unavailable, try again!" );
        }

        return result;
    }
}
