package actions.strategy;

import actions.filters.CustomerFilters;
import databaseworker.CustomerSqlQueries;
import databaseworker.DBConnectionPool;
import dataobjects.Address;
import dataobjects.Customer;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by CostelRo on 15.08.2018.
 */


public final class CustomerStrategy implements DataObjectStrategy
{
    /**
     * This method parses a String and creates a Customer object from that data.
     * @param line the text of each valid line from a CSV file
     * @return a List of objects containing, in order:
     *              - the Customer ID from the CSV archive, referenced by other objects in the archive;
     *              - the Customer object.
     */
    @Override
    public List<Object> parseObjectFromCSVString( String line )
    {
        String[] source = line.split( DataObjectStrategy.REGEX_TOKENS_SEPARATOR );

        // only used to correlate with other data in the CSV archive
        Integer idCustomerCSV = Integer.valueOf( source[0] );

        // each Customer can contain more than 1 address
        String[] dataForAddresses = Arrays.copyOfRange( source, 4, source.length );
        Set<Address> address = this.parseAddressesFromArrayOfString( dataForAddresses );

        // create the Customer
        Customer customer = new Customer( source[1], source[2], source[3], address );

        List<Object> result = new ArrayList<>(2);
        result.add( idCustomerCSV );
        result.add( customer );

        return result;
    }


    public Set<Address> parseAddressesFromArrayOfString( String[] source )
    {
        Set<Address> result = new HashSet<>();

        int indexOfCurrentAddress = 0;
        while( indexOfCurrentAddress < source.length-3 )
        {
            String country = source[indexOfCurrentAddress];
            String locality = source[indexOfCurrentAddress + 1];
            String street = source[indexOfCurrentAddress + 2];
            String number = source[indexOfCurrentAddress + 3];
            Address address = new Address( country, locality, street, number );
            result.add( address );

            indexOfCurrentAddress += 4;
        }

        return result;
    }


    /**
     * This method checks whether a string contains all the valid data needed to create a Customer object.
     * This is intended to be used when working with CSV files in this project.
     * This is intended to be used by the CSVParser class and other clients close to the original source of data.
     * @param line the String used as a source of data
     * @return boolean 'true' if the source has all the proper data, 'false' otherwise
     */
    @Override
    public boolean isValidLine( String line )
    {
        // TODO, together with validation for each field from the CSV line
        return true;
    }


    /**
     * This method writes a Customer object to a database, together with its related Address object(s).
     * @param object the Customer object
     * @return int the ID of the Customer in the database if the operation was successful, or -1 otherwise
     */
    @Override
    public int writeObjectToDatabase( Object object )
    {
        int result = -1;

        if( (object != null) && (object instanceof Customer) )
        {
            Connection con = DBConnectionPool.getMysqlConnection();
            if( con != null )
            {
                result = CustomerSqlQueries.insertCustomerIntoMysql( (Customer)object, con );

                DBConnectionPool.closeConnection( con );
            }
            else
            {
                System.out.println( "[cust1] Error: connection unavailable, try again!" );
            }
        }

        return result;
    }


    /**
     * This method reads data from the database and creates a Customer object.
     * @param idObjectDB the ID of the Customer in the database
     * @param con a database connection
     */
    @Override
    public Customer readObjectFromDatabase( int idObjectDB, Connection con )
    {
        return CustomerFilters.searchByOneID( idObjectDB ).get( idObjectDB );
    }

//        con = DBConnectionPool.getMysqlConnection();
//        if( con != null )
//        {
//            result = CustomerSqlQueries.getCustomerFromMysql( idObjectDatabase, con );
//            Map<Integer, List<String>> resultsFromDB = CustomerSqlQueries.getOneCustomerDataByIDFromMysql( idObjectDB,
//                                                                                                          con );
//            DBConnectionPool.closeConnection( con );
//        }
//        else
//        {
//            System.out.println( "[cust2] Error: connection unavailable, try again!" );
//        }


}
