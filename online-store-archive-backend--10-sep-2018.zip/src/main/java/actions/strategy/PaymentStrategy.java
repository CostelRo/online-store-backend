package actions.strategy;

import databaseworker.DBConnectionPool;
import databaseworker.PaymentSqlQueries;
import dataobjects.Payment;
import dataobjects.PaymentStatus;
import dataobjects.PaymentType;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by CostelRo on 16.08.2018.
 */


public final class PaymentStrategy implements DataObjectStrategy
{
    public static PaymentStatus getPaymentStatus( String source )
    {
        PaymentStatus result;

        switch( source )
        {
            case "pending":
                result = PaymentStatus.PENDING;
                break;
            case "processed":
                result = PaymentStatus.PROCESSED;
                break;
            default:
                result = null;
                break;
        }

        return result;
    }


    public static PaymentType getPaymentType( String source )
    {
        PaymentType result;

        switch( source )
        {
            case "cash":
                result = PaymentType.CASH;
                break;
            case "creditcard":
                result = PaymentType.CREDITCARD;
                break;
            case "paypal":
                result = PaymentType.PAYPAL;
                break;
            default:
                result = null;
                break;
        }

        return result;
    }


    /**
     * This method parses a String and creates a Payment object from that data.
     * @param line the text of each valid line from a CSV file
     * @return a List of objects containing, in order:
     *              - the Payment ID from the CSV archive;
     *              - the Payment object.
     */
    @Override
    public List<Object> parseObjectFromCSVString( String line )
    {
        String[] source = line.split( DataObjectStrategy.REGEX_TOKENS_SEPARATOR);

        Integer idPaymentOld = Integer.valueOf( source[0] );

        Integer idCart = Integer.valueOf( source[1] );
        Integer idCustomer = Integer.valueOf( source[2] );
        PaymentStatus status = getPaymentStatus( source[3] );
        PaymentType type = getPaymentType( source[4] );
        Double amount = Double.valueOf( source[5] );

        List<Object> result = new ArrayList<>(2);
        result.add( idPaymentOld );
        result.add( new Payment( idCart, idCustomer, status, type, amount ) );

        return result;
    }


    /**
     * This method checks whether a string contains all the valid data needed to create a Payment object.
     * This is intended to be used when working with CSV files in this project.
     * This is intended to be used mainly by the CSVParser class and other clients close to the original source of data.
     * @param line the String used as a source of data
     * @return boolean 'true' if the source has all the proper data, 'false' otherwise
     */
    @Override
    public boolean isValidLine( String line )
    {
        // TODO, together with validation for each field from the CSV line
        return true;
    }


    /**
     * This method writes a Payment object to a database.
     * @param object the Payment object
     * @return int the ID of the Payment in the database if the operation was successful, or -1 otherwise
     */
    @Override
    public int writeObjectToDatabase( Object object )
    {
        int result = -1;

        if( (object != null) && (object instanceof Payment) )
        {
            Connection con = DBConnectionPool.getMysqlConnection();
            if( con != null )
            {
                Payment payment = (Payment) object;
                result = PaymentSqlQueries.insertPaymentIntoMysql( payment, con );

                DBConnectionPool.closeConnection( con );
            }
            else
            {
                System.out.println( "[pay1] Error: connection unavailable, try again!" );
            }
        }

        return result;
    }


    /**
     * This method reads data from the database and creates a Payment object.
     * @param idOfObject the ID of the Payment in the database
     * @param con a database connection
     */
    @Override
    public Payment readObjectFromDatabase( int idOfObject, Connection con )
    {
        Payment result = null;

        con = DBConnectionPool.getMysqlConnection();
        if( con != null )
        {
            result = PaymentSqlQueries.getPaymentByIDFromMysql( idOfObject, con );
            DBConnectionPool.closeConnection( con );
        }
        else
        {
            System.out.println( "[pay2] Error: connection unavailable, try again!" );
        }

        return result;
    }
}
