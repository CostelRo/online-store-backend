package actions.reporter;


import actions.comparators.ByValueDescendingMapComparator_1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;


public class ReportTools
{
    public static List<String> sortMapByValuesDescending( final Map<String, Double> source )
    {
        List<String> result = new ArrayList<>( source.size() );

        List<Map.Entry<String, Double>> tempList = new ArrayList<>( source.entrySet() );
        Collections.sort( tempList, new ByValueDescendingMapComparator_1() );
        for( int i=0; i < source.size(); i++)
        {
            result.add( tempList.get( i ).getKey() + ":" + tempList.get( i ).getValue() );
        }

        return result;
    }


    public static List<String> createTopSalesAsList( int topSize, final List<String> fullData )
    {
        List<String> result = new ArrayList<>( topSize );

        int topLimit = ( topSize <= fullData.size() )
                ? topSize
                : fullData.size();
        result.addAll( fullData.subList( 0, topLimit ) );

        return result;
    }
}
