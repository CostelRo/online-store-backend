package actions.comparators;


import java.util.Comparator;
import java.util.Map;


public class ByValueDescendingMapComparator_2 implements Comparator<Map.Entry<String, String>>
{
    public int compare( Map.Entry<String, String> e1, Map.Entry<String, String> e2 )
    {
        return e2.getValue().compareTo( e1.getValue() );
    }
}
