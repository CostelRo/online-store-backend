import actions.csvworker.CSVArchiveImporter;
import databaseworker.CartSqlQueries;
import databaseworker.CustomerSqlQueries;
import databaseworker.DBConnectionPool;
import databaseworker.PaymentSqlQueries;
import databaseworker.ReceiptSqlQueries;
import dataobjects.Address;
import dataobjects.Cart;
import dataobjects.Customer;
import dataobjects.Payment;
import dataobjects.Receipt;

import java.sql.Connection;
import java.util.List;
import java.util.Map;

/**
 * Created by CostelRo on 14.08.2018.
 */


public class Store
{
    // fields
    private Map<Integer, Customer> cacheOfCustomers;
    private Map<Integer, Customer> cacheOfCarts;
    private Map<Integer, Customer> cacheOfPayments;


    // constructors


    // getters and setters


    // other methods

    /**
     * This method impotrs the store's data archive from CSV files to the new database created for this project.
     * @return 'false' if no importing errors were encountered, or 'true' otherwise
     */
    public boolean importCSVArchive()
    {
        String customersCSVFile = "CSV_Customers_short_v2.txt";
        String cartsCSVFile     = "CSV_Carts_short_v2.txt";
        String paymentsCSVFile  = "CSV_Payments_short_v2.txt";
        boolean result = CSVArchiveImporter.importArchive( customersCSVFile, cartsCSVFile, paymentsCSVFile );

        return result;
    }


    /**
     * This method writes into the database a receipt for each cart which does not already have one.
     * @return int = the number of receipts inserted into the database
     */
    public int writeMissingReceiptsIntoDatabase()
    {
        int result = 0;

        Connection con = DBConnectionPool.getMysqlConnection();
        if( con != null )
        {
            List<Integer> idCartsWithoutReceipts = ReceiptSqlQueries.getIDsOfCartsWithoutReceipt( con );
            for( int idCartDB : idCartsWithoutReceipts )
            {
                Cart cart = CartSqlQueries.getCartFromMysql( idCartDB, con );
                List<Payment> payments = PaymentSqlQueries.getPaymentsByCartFromMysql( idCartDB, con );
                Receipt properReceipt = new Receipt( cart, payments );
                ReceiptSqlQueries.insertReceiptIntoMysql( properReceipt, idCartDB, con );
                result++;
            }

            DBConnectionPool.closeConnection( con );
        }
        else
        {
            System.out.println( "[store1] Error: connection unavailable, try again!" );
        }

        return result;
    }


    /**
     * This method inserts in the database a new Address for an existing customer from the database
     * @param idCustomerDB the database ID of the Customer
     * @param newAddress the new Address object to be inserted in the database
     * @return int = the number of addresses inserted into the database if successful, or -1 otherwise
     */
    public static int insertNewAddressToOneCustomer( int idCustomerDB, Address newAddress )
    {
        int result = -1;

        Connection con = DBConnectionPool.getMysqlConnection();
        if( con != null )
        {
            result = CustomerSqlQueries.insertAddressIntoMysql( newAddress, idCustomerDB, con );

            DBConnectionPool.closeConnection( con );
        }
        else
        {
            System.out.println( "[store1] Error: connection unavailable, try again!" );
        }

        return result;
    }


    public static void displayTopCategories( List<String> results )
    {
        if( results == null || results.size() == 0 )
        {
            System.out.println( "- No available data in the database." );
        }
        else
        {
            for (String s : results)
            {
                String[] tokens = s.split(":");
                String category = tokens[0];
                String amount = tokens[1];
                System.out.printf( "- %s = %s RON\n", category, amount );
            }
        }
    }


    public static void displayTopCustomers( List<String> results )
    {
        if( results == null || results.size() == 0 )
        {
            System.out.println( "- No available data in the database." );
        }
        else
        {
            for (String s : results)
            {
                String[] tokens = s.split(":");
                String fullName = tokens[0];
                String email = tokens[1];
                String amount = tokens[2];
                System.out.printf( "- %s (%s) = %s RON\n", fullName, email, amount );
            }
        }
    }
}
