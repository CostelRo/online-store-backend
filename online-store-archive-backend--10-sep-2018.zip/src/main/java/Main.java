import databaseworker.DBConnectionPool;

import java.sql.Connection;
import java.sql.SQLException;


public class Main
{
    public static void main(String[] args)
    {
        Store testStore = new Store();

        // TEST: import all CSV archive
//        testStore.importCSVArchive();


        try( Connection con = DBConnectionPool.getMysqlConnection() )
        {
            // insert a new Address for an existing Customer
//            Address newAddress = new Address( "Romania", "Caracal", "Progresului", "13" );
//            Store.insertNewAddressToOneCustomer( 4, newAddress );

            // read a Customer from the database
//            int idCustomerDB = 4;
//            Map<Integer, Customer> searchResults = CustomerFilters.searchByOneID( idCustomerDB );
//            Customer customer = searchResults.get( idCustomerDB );
//            if( customer != null )
//            {
//                System.out.printf( "Customer #%d: %s\n", idCustomerDB, customer );
//            }
//            else
//            {
//                System.out.println( "No information in the database about Customer #" + idCustomerDB );
//            }


            // TEST: create & insert a receipt for a precise cart (e.g. selected from a GUI menu) into the database
//            int idCartDB = 6;
//            Cart cart1 = CartSqlQueries.getCartFromMysql(idCartDB, con);
//            List<Payment> payments = PaymentSqlQueries.getPaymentsByCartFromMysql(idCartDB, con);
//            Receipt receipt1 = new Receipt(cart1, payments);
//
//            int idReceiptDB_1 = ReceiptSqlQueries.insertReceiptIntoMysql(receipt1, idCartDB, con);
//            System.out.println( "\nReceipt #" + idReceiptDB_1 + " (for cart #" + idCartDB + ") added to database." );


            // TEST: insert all missing Receipts into the database
//            int counterWrittenReceipts = testStore.writeMissingReceiptsIntoDatabase();
//            System.out.println( "\nMissing receipts added: " + counterWrittenReceipts );


            // TEST: get a receipt in PDF format from the database to the local computer
//            int idReceiptDB_2 = 6;
//            String receiptPDFFromDB = ReceiptSqlQueries.getReceiptPDFByIdFromMysql(idReceiptDB_2, con);
//            System.out.println( "\nReceipt PDF from database: " + receiptPDFFromDB );


            // TEST: create a report with total sales for today, as a web page
//            LocalDate date_1 = LocalDate.now();
//            Report.dailySales( date_1 );


            // TEST: create a report with total sales for one day, as a web page
//            LocalDate date_2 = LocalDate.of( 2018, 3, 3 );
//            Report.dailySales( date_2 );


            // TEST: create a report with total sales per each category for the current month, as a web page
//            LocalDate date_3 = LocalDate.now();
//            Report.monthlyCategoriesSales( date_3.getMonthValue(), date_3.getYear() );


            // TEST: create a report with total sales per each category for the previous month, as a web page
//            LocalDate date_4 = LocalDate.now();
//            int previousMonth_4 = date_4.getMonth().minus( 1 ).getValue();
//            int year_4 = date_4.getYear();
//            if( previousMonth_4 == 12 )
//            {
//                year_4 -= 1;
//            }
//            Report.monthlyCategoriesSales( previousMonth_4, year_4 );


            // TEST: create a report with total sales per each category for one month, as a web page
//            int year_5 = 2018;
//            int month_5 = 6;
//            Report.monthlyCategoriesSales( month_5, year_5 );


            // TEST: create a report with a top of best sold categories for one month, as a web page
//            int year_6 = 2018;
//            int month_6 = 3;
//            int topSize_6 = 10;
//            Report.monthlyTopCategoriesBySales( month_6, year_6, topSize_6 );


            // TEST: create a report with a top of best sold categories for all-time, as a web page
//            int topSize_7 = 15;
//            Report.alltimeTopCategoriesBySales( topSize_7 );


            // TEST: create a report with a top of best customers for the current month, as a web page
//            LocalDate date_8 = LocalDate.now();
//            int month = date_8.getMonthValue();
//            int year = date_8.getYear();
//            int topSize_8 = 8;
//            Report.monthlyTopCustomersBySales( month, year, topSize_8 );


            // TEST: create a report with a top of best customers for the previous month, as a web page
//            LocalDate date_9 = LocalDate.now();
//            int previousMonth_9 = date_9.getMonth().minus( 1 ).getValue();
//            int year_9 = date_9.getYear();
//            if( previousMonth_9 == 12 )
//            {
//                year_9 -= 1;
//            }
//            int topSize_9 = 10;
//            Report.monthlyTopCustomersBySales( previousMonth_9, year_9, topSize_9 );


            // TEST: create a report with a top of best customers for one month, as a web page
//            int year_10 = 2018;
//            int month_10 = 6;
//            int topSize_10 = 5;
//            Report.monthlyTopCustomersBySales( month_10, year_10, topSize_10 );
        }
        catch( SQLException sqle )
        {
            sqle.printStackTrace();
        }
    }
}
